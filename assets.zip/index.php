<?php include("includes/header.php"); ?>
<!-- banner & banner content section start here  -->
<div class="banner mb-3">
    <img src="assets/images/banner.jpg" class="img-fluid" alt="BANNER IMAGE">
</div>

<?php
if (isset($_SESSION['message'])) {
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php 
unset($_SESSION['message']);   
}
?>

<div class="banner-content">
    <h1 class="text-center text-white mb-2">
        Make travelling a <span class="theme-color">pleasure.</span>
    </h1>
    <p class="text-center"><span id="custom-word"></span><span class="input-cursor"></span></p>
    <div class="text-center">
        <a href="#popular-place" class="btn btn-primary" id="explore">Explore Now!</a>
        <button class="btn btn-primary w-50 mx-auto" id="booking">Search Flight</button>
    </div>
</div>
<!-- banner & banner content section start here  -->

<!-- booking card section start here -->
<div class="booking-card" id="bookingCard">
    <div class="card w-75 mx-auto py-4 shadow">
        <div class="card-body">
            <form action="flights.php" method="POST">
            <div class="d-flex align-items-center gap-1">
                <div class="form-floating w-50">
                    <select class="form-select" id="floatingArival" name="arrival">
                      <option selected>Select your Arrival</option>
                      <?php
                        $query = "SELECT city_name FROM `citys`";
                        $result = mysqli_query($conn, $query);
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_assoc($result)){
                        ?>
                      <option value="<?=$row["city_name"];?>" <?= $row["city_name"] == "delhi" ? "selected" : "" ?>><?= ucfirst($row["city_name"]); ?>, IN</option>
                      <?php
                            }
                        }
                      ?>
                    </select>
                    <label for="floatingArival">From</label>
                </div>
                <div class="form-floating w-50">
                    <select class="form-select" id="floatingDeparture" name="departure">
                      <option selected>Select your Departure</option>
                      <?php
                        $query = "SELECT city_name FROM `citys`";
                        $result = mysqli_query($conn, $query);
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_assoc($result)){
                        ?>
                      <option value="<?=$row["city_name"];?>" <?= $row["city_name"] == "mumbai" ? "selected" : "" ?>><?= ucfirst($row["city_name"]); ?>, IN</option>
                      <?php
                            }
                        }
                      ?>
                    </select>
                    <label for="floatingDeparture">To</label>
                </div>
                <div class="form-floating w-50">
                    <select class="form-select" id="floatingClass" name="class">
                      <option>Select your Class</option>
                      <option value="economy" selected>Economy</option>
                      <option value="business">Business</option>
                    </select>
                    <label for="floatingClass">Class</label>
                </div>
                <div class="form-floating w-50">
                    <input type="date" class="form-control" id="floatingDate" placeholder="Enter Date" name="doj">
                    <label for="floatingDate">Select Date</label>
                </div>
                <button class="btn btn-primary" name="flightBtn"><i class="fa-solid fa-magnifying-glass fa-2xl"></i></button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- booking card section end here  -->

<!-- special offer section start here -->
<div class="special-offer container my-4">
    <div class="heading py-3">
        <h1 class="text-center">Airline Partner</h1>
    </div>
    <div class="offer-list gap-2 my-3">
        <div class="card shadow-lg">
            <img src="assets/images/indigo.jpg" class="card-img-top" alt="PLANE IMAGE">
            <span class="rating">5.0 <i class="fa-solid fa-star"></i></span>
            <div class="card-body">
                <h3 class="card-title">INDIGO</h3>
                <h6 class="mb-2"><i class="fa-solid fa-location-dot"></i> India</h6>
            </div>
        </div>
        <div class="card shadow-lg">
            <img src="assets/images/vistara.jpg" class="card-img-top" alt="PLANE IMAGE">
            <span class="rating">5.0 <i class="fa-solid fa-star"></i></span>
            <div class="card-body">
                <h3 class="card-title">VISTARA</h3>
                <h6 class="mb-2"><i class="fa-solid fa-location-dot"></i> India</h6>
            </div>
        </div>
        <div class="card shadow-lg">
            <img src="assets/images/spicejet.jpg" class="card-img-top" alt="PLANE IMAGE">
            <span class="rating">5.0 <i class="fa-solid fa-star"></i></span>
            <div class="card-body">
                <h3 class="card-title">SPICEJET</h3>
                <h6 class="mb-2"><i class="fa-solid fa-location-dot"></i> India</h6>
            </div>
        </div>
        <div class="card shadow-lg">
            <img src="assets/images/air-india.jpg" class="card-img-top" alt="PLANE IMAGE">
            <span class="rating">5.0 <i class="fa-solid fa-star"></i></span>
            <div class="card-body">
                <h3 class="card-title">AIR INDIA</h3>
                <h6 class="mb-2"><i class="fa-solid fa-location-dot"></i> India</h6>
            </div>
        </div>
    </div>
</div>
<!-- special offer section end here -->

<!-- guidelines section start here  -->
<div class="guidelines container-fluid bg-white my-4">
    <div class="guidelines-container my-2">
        <div class="left">
            <div class="heading py-3">
                <h2>Before <span class="theme-color">Travelling</span> Follow Our Guidelines</h2>
            </div>
            <div class="guidelines-list my-2">
                <ul>
                    <li>Ensure you have your passport, visa (if necessary), flight tickets, and any required identification.</li>
                    <li>Check baggage allowances and restrictions for your specific airline. Pack according to airline regulations.</li>
                    <li>Aim to reach the airport well in advance to allow time for security checks, especially during peak travel times.</li>
                    <li>Be prepared for security checks. Have your ID and boarding pass ready, remove electronic devices and liquids from your carry-on bags.</li>
                    <li>Check the departure screens for your flight's gate number and pay attention to announcements.</li>
                    <li>Check the specific COVID-19 requirements for your destination, including testing, vaccination, and quarantine rules.</li>
                    <li>If you have any health issues, consult a doctor before flying. Consider travel insurance coverage.</li>
                    <li>Always check with your airline for any specific guidelines or changes as regulations can vary based on airlines and destinations.</li>
                </ul>
            </div>
        </div>
        <div class="right">
            <img src="assets/images/flying-globe.gif" class="img-fluid" alt="GUIDELINES IMAGE">
        </div>
    </div>
</div>
<!-- guidelines section end here  -->

<!-- how it works section start here  -->
<div class="how-work container my-4">
    <div class="heading py-3">
        <h1 class="text-center">How It Works</h1>
    </div>
    <div class="works-list gap-5 my-4">
        <div class="card shadow">
            <div class="work-icon">
                <i class="fa-solid fa-calendar fa-2xl"></i>
            </div>
            <div class="card-body">
                <div class="card-title text-center">Book & Relax</div>
                <div class="card-text">Once booked, you receive immediate confirmation and can access your ticket electronically, reducing the need for physical tickets and allowing for easy access at the airport.</div>
            </div>
        </div>
        <div class="card shadow-lg">
            <div class="work-icon" id="second-icon">
                <i class="fa-solid fa-circle-check fa-2xl"></i>
            </div>
            <div class="card-body">
                <div class="card-title text-center">Smart Checklist</div>
                <div class="card-text">A smart checklist focuses on user experience, transparency in pricing, and providing convenient options before, during, and after the booking process to enhance customer satisfaction and loyalty.</div>
            </div>
        </div>
        <div class="card shadow">
            <div class="work-icon" id="third-icon">
                <i class="fa-solid fa-indian-rupee-sign fa-2xl"></i>
            </div>
            <div class="card-body">
                <div class="card-title text-center">Save More</div>
                <div class="card-text">Provide special discounts or offers during peak travel seasons or holidays to attract more users during these high-demand periods.</div>
            </div>
        </div>
    </div>
</div>
<!-- how it works section end here  -->

<!-- popular places section start here -->
<div class="popular-places container my-5" id="popular-place">
    <div class="heading py-3">
        <h1 class="text-center">Popular Places</h1>
    </div>
    <div class="places-list gap-2 my-3">
        <?php
            $result = mysqli_query($conn, "SELECT city_name FROM `citys` LIMIT 8");
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
        ?>
        <div class="card shadow-lg">
            <img src="https://images.pexels.com/photos/4428291/pexels-photo-4428291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="card-img-top" alt="PLACES IMAGE">
            <span class="rating">5.0 <span class="rating-icon"><i class="fa-solid fa-star"></i></span></span>
            <div class="card-body">
                <h3 class="card-title"><?= $row["city_name"] == "delhi" ? "New Delhi" : ucfirst($row["city_name"]) ?></h3>
                <h6 class="mb-2"><i class="fa-solid fa-location-dot"></i> India</h6>
            </div>
        </div>
        <?php
                }
            }
        ?>
    </div>
</div>
<!-- popular places section end here -->

<!-- testimonial section start here  -->
<div class="testimonial container my-4">
    <div class="heading py-3">
        <h1 class="text-center">Don't Trust Us, Trust Our Customers</h1>
    </div>
    <div class="testimonial-list gap-3 my-2">
        <div class="card shadow">
            <div class="card-body">
                <div class="card-title">
                    <div class="d-flex justify-content-between">
                        <div class="customer-info">
                            <h5 class="fw-bold">USER</h5>
                        </div>
                        <div class="customer-rating"><span class="rating-icon"><i class="fa-solid fa-star"></i></span>5.0</div>
                    </div>
                </div>
                <div class="card-text">Booking my recent flight was a hassle-free and convenient experience.</div>
            </div>
        </div>
        <div class="card shadow">
            <div class="card-body">
                <div class="card-title">
                    <div class="d-flex justify-content-between">
                        <div class="customer-info">
                            <h5 class="fw-bold">USER</h5>
                        </div>
                        <div class="customer-rating"><span class="rating-icon"><i class="fa-solid fa-star"></i></span>5.0</div>
                    </div>
                </div>
                <div class="card-text">Searching for flights and booking process was so easy.</div>
            </div>
        </div>
        <div class="card shadow">
            <div class="card-body">
                <div class="card-title">
                    <div class="d-flex justify-content-between">
                        <div class="customer-info">
                            <h5 class="fw-bold">USER</h5>
                        </div>
                        <div class="customer-rating"><span class="rating-icon"><i class="fa-solid fa-star"></i></span>5.0</div>
                    </div>
                </div>
                <div class="card-text">I appreciate the user-friendly interface and the straightforward process.</div>
            </div>
        </div>
        <div class="card shadow">
            <div class="card-body">
                <div class="card-title">
                    <div class="d-flex justify-content-between">
                        <div class="customer-info">
                            <h5 class="fw-bold">USER</h5>
                        </div>
                        <div class="customer-rating"><span class="rating-icon"><i class="fa-solid fa-star"></i></span>5.0</div>
                    </div>
                </div>
                <div class="card-text">This airline reservation website is a reliable companion for stress-free travel planning.</div>
            </div>
        </div>
    </div>
</div>
<!-- testimonial section end here  -->

<?php include("includes/footer.php"); ?>