<?php include("includes/header.php");
include "includes/functions.php";
if(isset($_SESSION['userLogged']) && $_SESSION['userLogged'] == true){

//for showing message    
if (isset($_SESSION['message'])) {
    ?>
    <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
      <?= $_SESSION['message']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php 
    unset($_SESSION['message']);   
    }
?>
  
<div class="pageNameBox container-fluid py-4">
    <div class="pageName">
        <h2 class="text-center">Ticket</h2>
    </div>
</div>

<div class="all-ticket container mb-4">
   <div class="all-ticket-container">
   <div class="card w-25 py-4 my-4">
    <div class="card-body">
        <div class="profile-photo mx-auto mb-3">
            <img src="assets/images/user.png" class="img-fluid" alt="PROFILE-IMAGE">
        </div>
        <div class="UserName border-bottom mb-3">
            <h4 class="text-center text-uppercase"><?= $_SESSION['fname'] ? $_SESSION['fname'] : "user" ?></h4>
        </div>
        <ul>
            <li><a href="tickets.php" class="user-active text-uppercase">View Ticket</a></li>
            <li><a href="profile.php" class="text-uppercase">Profile</a></li>
        </ul>
    </div>
   </div>
   <div class="card w-75 py-4 my-4">
    <div class="card-body">
    <table class="table table-striped table-bordered table-hover display" id="myTable">
                <thead>
                        <tr>
                        <th scope="col">Airline Icon</th>
                        <th scope="col">Airline Name</th>
                        <th scope="col">Flight Number</th>
                        <th scope="col">Arrival City</th>
                        <th scope="col">Departure City</th>
                        <th scope="col">Options</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
                    $userId = $_SESSION['userId'];
                    $result = mysqli_query($conn, "SELECT * FROM `tickets` WHERE user_id='$userId'");
                    if (mysqli_num_rows($result) > 0) {
                        while($row=mysqli_fetch_assoc($result)){
                            $flightId = $row["flight_id"];
                            $flightResult = mysqli_query($conn,"SELECT * FROM `flights` WHERE flight_id='$flightId'");
                            $flightRow = mysqli_fetch_assoc($flightResult);
                            $airId = $flightRow["airline_id"];
                            $airResult = mysqli_query($conn, "SELECT * FROM `airlines` WHERE airline_id='$airId'");
                            $airRow = mysqli_fetch_assoc($airResult);
                    ?>
                        <tr>
                        <td class="user-flight-icon"><img src="<?= $airRow["airline_image"]; ?>" alt="ICON" class="img-fluid"></td>
                        <td><?= $airRow["airline_name"]; ?></td>
                        <td><?= $flightRow["flight_number"]; ?></td>
                        <td><?= $flightRow["arrival_city"] == "delhi" ? "New Delhi" : ucfirst($flightRow["arrival_city"]) ; ?></td>
                        <td><?= ucfirst($flightRow["departure_city"]); ?></td>
                        <td><a href="booked.php?ticket_id=<?= base64_encode(urlencode($row["ticket_id"])) ?>" class="btn btn-primary">View Ticket</a></td>
                        </tr>
                    <?php
                        }
                    }else{
                    ?>
                    <tr>
                        <th colspan="6" class="text-center">No Ticket Found.</th>
                    </tr>
                    <?php    
                    }
                    ?>    
                </tbody>
            </table>
    </div>
   </div>
   </div>
</div>

<?php include("includes/footer.php");
}else{
    $_SESSION['message'] = "Login to Continue..";
    $_SESSION['message_type'] = "success";
    header("Location: /login.php");
}
?>