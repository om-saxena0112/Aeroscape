<?php include("includes/header.php"); ?>

<div class="pageNameBox container-fluid py-4  mb-2">
    <div class="pageName">
        <h2 class="text-center">Contact Us</h2>
    </div>
</div>

<?php
if (isset($_SESSION['message'])) {
?>
    <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php
    unset($_SESSION['message']);
}
?>

<div class="contact-box container mb-4">
    <div class="card shadow my-4">
        <div class="card-body">
            <div class="contact-us-heading">
                <h2 class="mb-3 text-center">Feel <span class="theme-color">Free</span> To Ask!</h2>
            </div>
            <div class="contact-details">
                <div class="card shadow">
                    <div class="contact-number text-center">
                        <div class="contact-icon mb-3">
                        <i class="fa-solid fa-phone fa-2xl"></i>
                        </div>
                        <p class="text-center"><a href="tel:<?= settings("support_number") ?>">+<?= settings("support_number") ?></a></p>
                    </div>
                </div>
                <div class="card shadow">
                    <div class="email text-center">
                        <div class="contact-icon mb-3">
                        <i class="fa-solid fa-envelope fa-2xl"></i>
                        </div>
                        <p class="text-center"><a href="mailto:<?= settings("support_email") ?>"><?= settings("support_email") ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow my-4">
        <div class="card-body">
            <div class="contact-us-heading">
                <h2 class="mb-3 text-center">Frequently <span class="theme-color">Asked</span> Questions (FAQ)</h2>
            </div>
            <div class="faq-box">
            <div class="topic">
                <div class="open">
                <h2 class="question">How do I make a flight booking on Aeroscape?</h2>
                <span class="faq-t"></span>
                </div>
                <p class="answer">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
            </div>
            <div class="topic">
                <div class="open">
                <h2 class="question">How can I avail budget air tickets on Aeroscape?
                </h2><span class="faq-t"></span>
                </div>
                <p class="answer">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
            </div>
            <div class="topic">
                <div class="open">
                <h2 class="question">What is an E-ticket and how do I use after I purchase?
                </h2><span class="faq-t"></span>
                </div>
                <p class="answer">An E-ticket,short for electronic ticket, is a digital ticket that is stored electronically and can be used for travel, events, or other purposes.</p>
            </div>
            <div class="topic">
                <div class="open">
                <h2 class="question">What is the baggage limitation and allowance?
                </h2><span class="faq-t"></span>
                </div>
                <p class="answer">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
            </div>
            </div>
        </div>
    </div>
    <div class="card shadow my-4">
        <div class="card-body">
            <div class="contact-us-heading">
                <h2 class="mb-3 text-center">Want to <span class="theme-color">Ask</span> Something?</h2>
            </div>
            <div class="row">
                <div class="col-6 support-image">
                    <img src="assets/images/suuport.gif" alt="CONTACT US">
                </div>
                <div class="col-6 support-form my-4 py-4">
                    <form action="admin/includes/code.php" method="POST">
                    <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingName" placeholder="Enter Name" name="user_name" required>
                    <label for="floatingName">Enter your Name</label>
                    </div>
                    <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="floatingEmail" placeholder="Enter Emai" name="user_email" required>
                    <label for="floatingEmail">Enter your Email</label>
                    </div>
                    <div class="form-floating mb-3">
                    <textarea class="form-control" id="floatingMessage" placeholder="Enter Message" name="user_message" style="height: 120px;" required></textarea>
                    <label for="floatingMessage">Enter your Message here</label>
                    </div>
                    <div class="text-center">
                        <button type="submit" name="supportBtn" class="w-50 btn btn-primary text-uppercase">Submit</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>