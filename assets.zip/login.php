<?php include("includes/header.php");
if(isset($_SESSION['userLogged'])){
    header("Location: /flight/");
}else{
?>

<div class="pageNameBox container-fluid py-4  mb-2">
    <div class="pageName">
        <h2 class="text-center">Login</h2>
    </div>
</div>

<?php
if (isset($_SESSION['message'])) {
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php 
unset($_SESSION['message']);   
}
?>

<div class="login-form mb-4">
    <div class="login-container w-75 mx-auto">
        <div class="card shadow w-50 mx-auto py-4">
            <div class="login-heading">
                <h3 class="text-center">Welcome Back!</h3>
            </div>
            <div class="card-body">
            <form action="admin/includes/code.php" method="POST">
            <div class="form-floating w-75 mx-auto mb-3">
                <input type="email" class="form-control" id="floatingInput" name="email" placeholder="name@example.com">
                <label for="floatingInput">Email address</label>
            </div>
            <div class="form-floating w-75 mx-auto mb-3">
                <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Password">
                <label for="floatingPassword">Password</label>
            </div>
            <div class="text-center mb-3">
            <button class="btn btn-primary w-50 mx-auto mb-3" name="loginBtn">Login</button>
            </div>
            </form>
            <div class="signup-link mb-3">
                <p class="text-center mb-0">Don't Have an Account! <a href="register.php" class="theme-color fw-bold">Sign up Here.</a></p>
            </div>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php");
}
?>