<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
// for showing any message     
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0"><span class="theme-color">All</span> Cities</h3>
                <a href="create-city.php" class="btn btn-primary">Add City <i class="fa-solid fa-plus"></i></a>
            </div>
            <div class="cities-data">
            <table class="table table-striped table-bordered table-hover" id="myTable">
                <thead>
                        <tr>
                        <th scope="col">S.NO.</th>
                        <th scope="col">Airport Name</th>
                        <th scope="col">City Name</th>
                        <th scope="col">Options</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM `citys`";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) > 0) {
                        $sno = 0;
                        while($row=mysqli_fetch_assoc($result)){
                            $sno = $sno + 1;
                    ?>
                        <tr>
                        <th scope="row"><?= $sno; ?></th>
                        <td><?= $row["city_airport_name"]; ?></td>
                        <td><?= ucfirst($row["city_name"]); ?>, IN</td>
                        <td><div class="d-flex gap-1">
                        <a href="edit.php?id=<?= base64_encode(urlencode($row["city_id"])); ?>" class="btn btn-primary"><i class="fa-solid fa-pen-to-square"></i></a>
                        <a href="delete.php" class="btn btn-outline-danger"><i class="fa-solid fa-trash"></i></a>
                        </div></td>
                        </tr>
                    <?php
                        }
                    }else{
                    ?>
                    <tr>
                        <th scope="colspan">No ✈️ Found.</th>
                    </tr>
                    <?php    
                    }
                    ?>    
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>