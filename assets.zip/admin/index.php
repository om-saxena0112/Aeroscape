<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && isset($_SESSION['adminLogged']) == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
$date = date("Y-m-d");
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="dashboard-heading mb-3">
                <h3><span class="theme-color">Dash</span>board</h3>
            </div>
            <div class="dashboard-data mb-4">
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-plane fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Airlines</h6>
                    <h6 class="mb-0 text-center dash-count fw-bold"><?= fetchData("airlines"); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-plane-up fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Flights</h6>
                    <h6 class="mb-0 text-center dash-count fw-bold"><?= fetchData("flights"); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-calendar-days fa-2xl"></i>
                    </div>
                    <div class="card-info">
                        <h6 class="text-center text-uppercase fw-bold">Today's Schedule</h6>
                        <h6 class="mb-0 text-center dash-count fw-bold"><?= fetchTodayData("flights_schedule", $date); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-money-bill-1 fa-2xl"></i>
                    </div>
                    <div class="card-info">
                        <h6 class="text-center text-uppercase fw-bold">Today's Income</h6>
                        <h6 class="mb-0 text-center">₹<span class="dash-count fw-bold"><?= fetchTodayIncome("tickets", "ticket_price",  $date); ?></span></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-money-bill-1 fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Total Income</h6>
                    <h6 class="mb-0 text-center">₹<span class="dash-count fw-bold"><?= fetchColumnIncome("tickets", "ticket_price"); ?></span></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-user fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Users</h6>
                    <h6 class="mb-0 text-center dash-count fw-bold fw-bold"><?= fetchData("users"); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-user fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Users</h6>
                    <h6 class="mb-0 text-center dash-count fw-bold fw-bold"><?= fetchData("users"); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-calendar-days fa-2xl"></i>
                    </div>
                    <div class="card-info">
                        <h6 class="text-center text-uppercase fw-bold">All Schedule</h6>
                        <h6 class="mb-0 text-center dash-count fw-bold"><?= fetchData("flights_schedule"); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-note-sticky fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Total Enquiries</h6>
                    <h6 class="mb-0 text-center dash-count fw-bold"><?= fetchData("enquires"); ?></h6>
                    </div>
                </div>
                <div class="card">
                    <div class="card-icon">
                    <i class="fa-solid fa-city fa-2xl"></i>
                    </div>
                    <div class="card-info">
                    <h6 class="text-center text-uppercase fw-bold">Total Cites</h6>
                    <h6 class="mb-0 text-center dash-count fw-bold"><?= fetchData("citys"); ?></h6>
                    </div>
                </div>
            </div>
            <div class="dashboard-heading d-flex justify-content-between mb-3">
                <h3><span class="theme-color">Pending</span> Enquiries</h3>
                <a href="enquires.php" class="text-primary fw-bold">View All</a>
            </div>
            <div class="enquire-data">
                <table class="table table-striped table-bordered table-hover display" id="dashboardTable">
                    <thead>
                            <tr>
                            <th scope="col">User Name</th>
                            <th scope="col">User Email</th>
                            <th scope="col">User Message</th>
                            <th scope="col">Status</th>
                            </tr>
                    </thead>
                    <tbody>
                    <?php
                        $result = mysqli_query($conn, "SELECT * FROM `enquires` WHERE status=0 LIMIT 5");
                        if (mysqli_num_rows($result) > 0) {
                            while($row=mysqli_fetch_assoc($result)){
                    ?>
                            <tr>
                            <td><?= ucfirst($row["user_name"]); ?></td>
                            <td><?= $row["user_email"]; ?></td>
                            <td><?= $row["user_message"]; ?></td>
                            <td><?= $row["status"] == 0 ? "<span class='badge text-bg-warning'>Pending</span>" : "<span class='badge text-bg-success'>Resolved</span>" ?></td>
                            </tr>
                    <?php
                        }}else{
                    ?>
                        <tr>
                            <th colspan="4" class="text-center">No New Enquires Found.</th>
                        </tr>
                    <?php    
                        }
                    ?>    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
    echo $page;
}
?>