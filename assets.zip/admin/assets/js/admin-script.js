// to hide the popup message 
let alert = document.querySelector(".alert");
if(alert){
    setTimeout(() => {
        alert.classList.remove("show");
    }, 2000);
}

// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}

//flight number generator
if(document.getElementById("genrateBtn")){
  document.getElementById("genrateBtn").addEventListener("click", (e)=>{
    e.preventDefault();
    let airlineName = document.getElementById("floatingAirline") ? document.getElementById("floatingAirline").value : "";
    let flightNumber;
    console.log(airlineName);
    if(airlineName != "Select your Airline Company"){
      airlineName = airlineName.charAt(0).toUpperCase();
      flightNumber = Math.floor(Math.random() * 9000 + 1000);
      flightNumber = airlineName + flightNumber;
      document.getElementById("floatingFlightNumber").value = flightNumber;
    }else{
      window.alert("Please select an airline company First");
    } 
  });
}

//datatable
$(document).ready( function () {
  $('#myTable').DataTable({
      responsive: true
  });
} );
//datatable for dashboard page
$(document).ready( function () {
  $('#dashboardTable').DataTable({
    "paging": false,
    "info":  false,
    "dom": 'rtip',
     "responsive": true
  });
} );

//sibar toggle button
let sideBtn = document.querySelector(".sidebar-btn");
sideBtn.addEventListener("click", (e) =>{
    e.preventDefault();
    let sidebar = document.querySelector(".admin-sidebar");
    sidebar.classList.toggle("sidebar-active");
});

//count the number on page load
$('.dash-count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 2000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});

//setting time
$(document).ready(function(){
setInterval(function(){
      $("#currentTime").load(window.location.href + " #currentTime" );
}, 1000);
});
