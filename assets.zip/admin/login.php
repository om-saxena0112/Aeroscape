<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
    header("Location: /admin/");
}else{
if(isset($_SESSION['message']) && isset($_SESSION['message_type'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
unset($_SESSION['message_type']);
}
?>

<div class="container-fluid admin-login-form">
    <div class="container login-container">
                <div class="card shadow-lg py-1">
                    <div class="card-body">
                        <form action="includes/code.php" method="POST">
                            <div class="company-logo">
                                <h2 class="text-center mb-3"><span class="theme-color">Aero</span>scape</h2>
                            </div>
                            <div class="admin-login-heading">
                                <h3 class="text-center fw-bold mb-3">Welcome Back!</h3>
                            </div>
                            <div class="form-floating w-75 mx-auto mb-3">
                                <input type="email" class="form-control" id="floatingEmail" name="email" placeholder="Enter Email" required>
                                <label for="floatingEmail">Enter Email</label>
                            </div>
                            <div class="form-floating w-75 mx-auto mb-3">
                                <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Enter Password" required>
                                <label for="floatingPassword">Enter Password</label>
                            </div>
                            <div class="text-center mb-2">
                            <button type="submit" class="btn btn-primary w-50" name="adminBtn">Login</button>
                            </div>
                        </form>
                </div>
    </div>
</div>

<?php
include "includes/admin_footer.php";
}
?>