<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0"><span class="theme-color">All</span> Enquires</h3>
            </div>
            <div class="flight-data">
            <table class="table table-striped table-bordered table-hover display" id="myTable">
                <thead>
                        <tr>
                        <th scope="col">S.NO.</th>
                        <th scope="col">User Name</th>
                        <th scope="col">User Email</th>
                        <th scope="col">User Message</th>
                        <th scope="col">Status</th>
                        <th scope="col">Options</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT * FROM `enquires`";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) > 0) {
                        $sno = 0;
                        while($row=mysqli_fetch_assoc($result)){
                            $sno = $sno + 1;
                    ?>
                        <tr>
                        <th scope="row"><?= $sno; ?></th>
                        <td><?= ucfirst($row["user_name"]); ?></td>
                        <td><?= $row["user_email"]; ?></td>
                        <td><?= $row["user_message"]; ?></td>
                        <td><?= $row["status"] == 0 ? "<span class='badge text-bg-warning'>Pending</span>" : "<span class='badge text-bg-success'>Resolved</span>" ?></td>
                        <td><div class="d-flex gap-1">
                        <a href="edit.php" class="btn btn-primary"><i class="fa-solid fa-pen-to-square"></i></a>
                        <a href="delete.php" class="btn btn-outline-danger"><i class="fa-solid fa-trash"></i></a>
                        </div></td>
                        </tr>
                    <?php
                        }
                    }else{
                    ?>
                    <tr>
                        <th colspan="6" class="text-center">No New Enquires Found.</th>
                    </tr>
                    <?php    
                    }
                    ?>    
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>