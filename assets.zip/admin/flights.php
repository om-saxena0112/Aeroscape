<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0"><span class="theme-color">All</span> Flights</h3>
                <a href="create-flight.php" class="btn btn-primary">Add Flight <i class="fa-solid fa-plus"></i></a>
            </div>
            <div class="flight-data">
            <table class="table table-striped table-bordered table-hover display" id="myTable">
                <thead>
                        <tr>
                        <th scope="col">S.NO.</th>
                        <th scope="col">Airline Icon</th>
                        <th scope="col">Airline Name</th>
                        <th scope="col">Flight Number</th>
                        <th scope="col">Arrival City</th>
                        <th scope="col">Destination City</th>
                        <th scope="col">Arrival Time</th>
                        <th scope="col">Destination Time</th>
                        <th scope="col">Economy Price</th>
                        <th scope="col">Bussiness Price</th>
                        <th scope="col">Status</th>
                        <th scope="col">Options</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM `flights` ORDER BY flight_id DESC");
                    if (mysqli_num_rows($result) > 0) {
                        $sno = 0;
                        while($row=mysqli_fetch_assoc($result)){
                            $sno = $sno + 1;
                            $airId = $row["airline_id"];
                            $airQuery= "SELECT * FROM `airlines` WHERE airline_id='$airId'";
                            $airResult = mysqli_query($conn,$airQuery);
                            $airRow = mysqli_fetch_assoc($airResult);
                    ?>
                        <tr>
                        <th scope="row"><?= $sno; ?></th>
                        <td class="admin-flight-icon"><img src="../<?= $airRow["airline_image"]; ?>" alt="ICON" class="img-fluid"></td>
                        <td><?= ucfirst($airRow["airline_name"]); ?></td>
                        <td><?= $row["flight_number"]; ?></td>
                        <td><?= ucfirst($row["arrival_city"]); ?></td>
                        <td><?= ucfirst($row["departure_city"]); ?></td>
                        <td><?= date("h:i a", strtotime($row["arrival_time"])); ?></td>
                        <td><?= date("h:i a", strtotime($row["departure_time"])); ?></td>
                        <td>₹<?= number_format($row["economy_price"]); ?></td>
                        <td>₹<?= number_format($row["bussiness_price"]); ?></td>
                        <td><?= $row["status"] == 1 ? "<span class='badge text-bg-success'>Active</span>" : "<span class='badge text-bg-danger'>Not Active</span>" ?></td>
                        <td><div class="d-flex gap-1">
                        <a href="edit-flights.php?id=<?= base64_encode(urlencode($row["flight_id"]))?>" class="btn btn-primary"><i class="fa-solid fa-pen-to-square"></i></a>
                        <a href="includes/delete.php?fid=<?= base64_encode(urlencode($row["flight_id"]))?>" class="btn btn-outline-danger" onclick=" return confirm('Are you sure you want to delete the data?')"><i class="fa-solid fa-trash"></i></a>
                        </div></td>
                        </tr>
                    <?php
                        }
                    }else{
                    ?>
                    <tr>
                        <th colspan="12" class="text-center">No ✈️ Found.</th>
                    </tr>
                    <?php    
                    }
                    ?>    
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>