<?php 
require "database/dbconn.php";
require "database/function.php";
session_start();
//this will turn output buffer on which can help header function to work properly.
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=ucfirst(settings("website_title"));?> | <?=ucfirst(settings("website_name"));?></title>
    <!-- Favicon link -->
    <link rel="shortcut icon" href="../../assets/images/favicon.ico" type="image/x-icon" />
    <!-- bootstrap link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" />
    <!-- font awesome link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- datatable css cdn link  -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" />
    <!-- custom css -->
    <link rel="stylesheet" href="assets/css/admin-style.css" />
</head>
<body>
    <main>
    <?php
    $page = basename($_SERVER["PHP_SELF"]);
    if($page != "login.php"){
        $websiteName = settings("website_name");
        $webSplitName = str_split($websiteName, 4);
    ?>
    <!-- header & sidebar section start here -->
    <nav class="navbar navbar-expand-lg bg-white sticky-top shadow">
    <div class="container-fluid">
        <div class="d-flex">
        <button class="btn btn-base border sidebar-btn me-2"><i class="fa-solid fa-bars"></i></button>
        <a class="navbar-brand" href="/admin/"><span class="theme-color"><?=ucfirst($webSplitName[0])?></span><?=str_replace($webSplitName[0], "", $websiteName)?></a>
        </div>
        <div class="d-flex">
        <button class="btn btn-primary fw-bold me-2 currentTime"><i class="fa-solid fa-clock"></i> <span id="currentTime"><?= $serverTime; ?></span></button>
        <button class="btn btn-outline-primary fw-bold text-uppercase me-2"><i class="fa-solid fa-circle-user fa-lg"></i> <span class="admin-name"><?=$_SESSION['adminName'];?></span></button>   
        <a href="includes/logout.php" class="btn btn-danger" onclick="return confirm('Are you sure you want to logout?')"><i class="fa-solid fa-right-from-bracket"></i> <span class="admin-logout">logout</span></a>
        </div>
        </div>
    </div>
    </nav>
    <?php
        include "admin_sidebar.php";
        }
    ?>