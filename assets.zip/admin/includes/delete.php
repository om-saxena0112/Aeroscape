<?php
require "../database/dbconn.php";
session_start();

if(isset($_GET["fid"]) || isset($_GET["sid"]) || isset($_GET["aid"]) || isset($_GET["cid"]) || isset($_GET["uid"]) || isset($_GET["eid"])){
    $message = "";

    if($_GET["fid"]){
        $id = base64_decode(urldecode($_GET["fid"]));
        $result = mysqli_query($conn, "DELETE FROM `flights` WHERE flight_id='$id'");
        $message = "Flight Record Deleted SuccessFully.";
    }else if($_GET["sid"]){
        $id = base64_decode(urldecode($_GET["sid"]));
        $result = mysqli_query($conn, "DELETE FROM `flights_schedule` WHERE schedule_id='$id'");
        $message = "Schedule Record Deleted SuccessFully.";
    }else if($_GET["aid"]){
        $id = base64_decode(urldecode($_GET["aid"]));
        $result = mysqli_query($conn, "DELETE FROM `airlines` WHERE airline_id='$id'");
        $message = "Airline Record Deleted SuccessFully.";
    }else if($_GET["cid"]){
        $id = base64_decode(urldecode($_GET["cid"]));
        $result = mysqli_query($conn, "DELETE FROM `citys` WHERE city_id='$id'");
        $message = "City Record Deleted SuccessFully.";
    }else if($_GET["uid"]){
        $id = base64_decode(urldecode($_GET["uid"]));
        $result = mysqli_query($conn, "DELETE FROM `users` WHERE user_id='$id'");
        $message = "User Record Deleted SuccessFully.";
    }else if($_GET["eid"]){
        $id = base64_decode(urldecode($_GET["eid"]));
        $result = mysqli_query($conn, "DELETE FROM `enquires` WHERE id='$id'");
        $message = "Enquire Record Deleted SuccessFully.";
    }


    if($result){
        $_SESSION['message'] = $message;
        $_SESSION['message_type'] = "success";
        header("Location: ../flights.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!.";
        $_SESSION['message_type'] = "danger";
        header("Location: ../flights.php");
    }

}else{
    $_SESSION['message'] = "ID Required in order to delete record..";
    $_SESSION['message_type'] = "danger";
    header("Location: /admin/");
}

?>