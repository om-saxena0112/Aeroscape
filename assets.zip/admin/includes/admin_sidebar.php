<?php
?>
<div class="d-flex flex-column flex-shrink-0 p-3 bg-white admin-sidebar">
        <ul class="nav nav-pills flex-column mb-auto">
        <li>
            <a href="/admin/" class="nav-link mb-2 <?=$page == "index.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-house me-2"></i>
            Dashboard
            </a>
        </li>
        <li>
            <p class="admin-sidebar-heading">
            Flights & Airline Management
            </p>
        </li>
        <li>
            <a href="flights.php" class="nav-link mb-2 <?=$page == "flights.php" || $page == "create-flight.php" || $page == "edit-flights.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-plane-up me-2"></i>
            Flights
            </a>
        </li>
        <li>
            <a href="flights-schedule.php" class="nav-link mb-2 <?=$page == "flights-schedule.php" || $page == "create-schedule-flight.php" || $page == "edit-flights-schedule.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-plane-up me-2"></i>
            Flights Schedule
            </a>
        </li>
        <li>
            <a href="airlines.php" class="nav-link mb-2 <?=$page == "airlines.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-plane-departure me-2"></i>
            Airlines
            </a>
        </li>
        <li>
            <p class="admin-sidebar-heading">
            Popular Places
            </p>
        </li>
        <li>
            <a href="cities.php" class="nav-link mb-2 <?=$page == "cities.php" || $page == 'create-city.php' ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-city me-2"></i>
            Cities
            </a>
        </li>
        <li>
            <p class="admin-sidebar-heading">
            Tickets Management
            </p>
        </li>
        <li>
            <a href="all-tickets.php" class="nav-link mb-2 <?=$page == "all-tickets.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-city me-2"></i>
            All Tickets
            </a>
        </li>
        <li>
            <p class="admin-sidebar-heading">
            Users & Support Management
            </p>
        </li>
        <li>
            <a href="users.php" class="nav-link mb-2 <?=$page == "users.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-user me-2"></i>
            Users
            </a>
        </li>
        <li>
            <a href="enquires.php" class="nav-link mb-2 <?=$page == "enquires.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-clipboard me-2"></i>
            Enquires
            </a>
        </li>
        <li>
            <p class="admin-sidebar-heading">
            Website Settings
            </p>
        </li>
        <li>
            <a href="settings.php" class="nav-link mb-2 <?=$page == "settings.php" ? "active shadow" : "text-dark"?>">
            <i class="fa-solid fa-gear me-2"></i>
            Settings
            </a>
        </li>
        </ul>
</div>
    <!-- header & sidebar section end here  -->
<div class="admin-main">