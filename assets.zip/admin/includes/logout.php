<?php
// for logout or destory session
session_start();
unset($_SESSION['adminLogged']);
unset($_SESSION['adminName']);
$_SESSION['message_type'] = "success";
$_SESSION['message'] = "Logout Successfully.";
header("Location: /admin/login.php");

?>