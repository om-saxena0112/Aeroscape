<?php
require "../database/dbconn.php";
include "../../includes/functions.php";
session_start();

// for admin pannel 
if(isset($_POST["adminBtn"])){

    $email = $_POST["email"];
    $password = $_POST["password"];

    $query = "SELECT * FROM `admin` WHERE admin_email='$email' AND admin_password='$password'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if(mysqli_num_rows($result) > 0){
        $_SESSION['adminLogged'] = true;
        $_SESSION['adminName'] = $row["admin_name"];
        $_SESSION['message_type'] = "success";
        $_SESSION['message'] = "Login Successful.";
        header("Location: /admin/");
    }else{
        $_SESSION['message'] = "Enter Valid Email or Password..";
        $_SESSION['message_type'] = "danger";
        header("Location: ../login.php");
    }
}

// for new user/register 
if (isset($_POST["registerBtn"])){

    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $email = $_POST["email"];
    $dob = $_POST["dob"];
    $age = ageCal($_POST["dob"]);
    $phone = $_POST["phone"];
    $password = $_POST["password"];
    $cPassword = $_POST["cPassword"];
    $address = "";
    $status = 1;
    //checking whether the entered email is already in use or not.
    $emailResult = mysqli_query($conn, "SELECT email FROM `users` WHERE email='$email'");
    if(mysqli_num_rows($emailResult) > 0){
        $_SESSION['message'] = "Email address already exist! Try login..";
        $_SESSION['message_type'] = "danger";
        header("Location: /login.php");
    }
    //checking whether the entered phone is already in use or not.
    $phoneResult = mysqli_query($conn, "SELECT phone FROM `users` WHERE phone='$phone'");
    if(mysqli_num_rows($phoneResult) > 0){
        $_SESSION['message'] = "Phone Number already exist! Try login..";
        $_SESSION['message_type'] = "danger";
        header("Location: /login.php");
    }
    //checking whether password and confirm password are same or not
    if($password == $cPassword){
     $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
     $query = "INSERT INTO `users`(`first_name`, `last_name`, `age`, `gender`, `email`, `phone`, `address`, `state`, `pincode`, `dob`, `password`,`status`) VALUES ('$fname','$lname','$age','','$email','$phone','$address','','','$dob','$password', '$status')";
     $result = mysqli_query($conn, $query);

     if($result){
        $_SESSION['message'] = "Register Successfully. Login to continue..";
        $_SESSION['message_type'] = "success";
        header("Location: /login.php");
     }else{
        $_SESSION['message'] = "Something Went Wrong..";
        $_SESSION['message_type'] = "danger";
        header("Location: /register.php"); 
     }
     }else{
        $_SESSION['message'] = "Password and Confrim Password must be same..";
        $_SESSION['message_tpye'] = "danger";
        header("Location: /register.php");
     }
    
}

// for existing user to login for booking ticket
if(isset($_POST["loginBtn"])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM `users` WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $query);
    if(mysqli_num_rows($result) > 0){
        while ($row=mysqli_fetch_assoc($result)) {
            $db_password = $row["password"];
            if(password_verify($password, $db_password)){
                $_SESSION['userId'] = $row["user_id"];
                $_SESSION['userLogged'] = true;
                $_SESSION['fname'] = $row["first_name"];
                $_SESSION['message'] = "Login Successfully.";
                $_SESSION['message_type'] = "success";
                header("Location: /");
            }else{
                $_SESSION['message'] = "Incorrect Password. Try Again..";
                $_SESSION['message_type'] = "danger";
                header("Location: /login.php");
            }
        }
    }else{
        $_SESSION['message'] = "Email not Found.";
        $_SESSION['message_type'] = "danger";
        header("Location: /login.php");
    }
}

// for searching flights 
if(isset($_POST["flightBtn"])){

    $arrivalCity = $_POST["arrival"];
    $departureCity = $_POST["departure"];
    $class = $_POST["class"];
    $doj = $_POST["doj"];

    $query = "SELECT * FROM `flights` WHERE arrival_city='$arrivalCity' AND departure_city='$departureCity'";
    $result = mysqli_query($conn, $query);

    if(mysqli_fetch_row($result) > 0){
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        header("Location: /flights.php");
    }else{
        $_SESSION['message'] = "No Flights Available for these citys.";
        header("Location: /");
    }
}

//for adding flights 
if(isset($_POST["addFlightBtn"])){

    $airlineName = $_POST["airline_name"];
    $stop = $_POST["flight_stop"];
    $duration = $_POST["duration"];
    $arrivalCity = $_POST["arrival_city"];
    $departureCity = $_POST["departure_city"];
    $arrivalTime = $_POST["arrival_time"];
    $departureTime = $_POST["departure_time"];
    $economyPrice = $_POST["economy_price"];
    $bussinessPrice = $_POST["bussiness_price"];
    $flightNumber = $_POST["flight_number"];
    $status = 1;

    $airQuery = "SELECT airline_id FROM `airlines` WHERE airline_name='$airlineName'";
    $airResult = mysqli_query($conn, $airQuery);
    if(mysqli_num_rows($airResult) == 1){
    $airRow = mysqli_fetch_assoc($airResult);
    $airlineId = $airRow["airline_id"];

    $query = "INSERT INTO `flights`(`airline_id`, `arrival_time`, `departure_time`, `duration`, `arrival_city`, `departure_city`, `economy_price`, `bussiness_price`, `flight_stop`, `flight_number`, `status`) VALUES ('$airlineId','$arrivalTime','$departureTime','$duration','$arrivalCity','$departureCity','$economyPrice','$bussinessPrice','$stop','$flightNumber','$status')";
    $result = mysqli_query($conn, $query);
    if($result){
        $_SESSION['message'] = "Flight Record Add Successfully.";
        $_SESSION['message_type'] = "success";
        header("Location: ../flights.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong.";
        $_SESSION['message_type'] = "danger";
        header("Location: ../create-flight.php");
    }

    }else{
        $_SESSION['message'] = "No AirLine Found";
        $_SESSION['message_type'] = "danger";
        header("Location: ../create-flight.php");
    }
}

//for adding schedule for the flights
if(isset($_POST["scheduleBtn"])){ 
    
    $flightNumber = $_POST["flight_number"];
    $arrivalCity = $_POST["arrival_city"];
    $destinationCity = $_POST["departure_city"];
    $economySeat = $_POST["economy_seat"];
    $businessSeat = $_POST["business_seat"];
    $status = 1;
    $scheduleDate = $_POST["schedule_date"];

    $flightResult = mysqli_query($conn, "SELECT flight_id FROM `flights` WHERE flight_number='$flightNumber'");
    if(mysqli_num_rows($flightResult) > 0){
        $flightRow = mysqli_fetch_assoc($flightResult);
        $flightId = $flightRow["flight_id"];

        $result = mysqli_query($conn, "INSERT INTO `flights_schedule`(`flight_id`, `arrival_city`, `departure_city`, `economy_seat`, `bussiness_seat`, `status`, `schedule_date`) VALUES ('$flightId','$arrivalCity','$destinationCity','$economySeat','$businessSeat','$status','$scheduleDate')");

        if($result){
            $_SESSION['message'] = "Schedule Added Successfully.";
            $_SESSION['message_type'] = "success";
            header("Location: ../flights-schedule.php");
        }else{
            $_SESSION['message'] = "Something went wrong!";
            $_SESSION['message_type'] = "danger";
            header("Location: ../create-schedule-flight.php");
        }

    }else{
        $_SESSION['message'] = "No Flight found against given flight number";
        $_SESSION['message_type'] = "danger";
        header("Location: ../create-schedule-flight.php");
    }
}

// for adding cities
if(isset($_POST["cityBtn"])){

    $cityName = $_POST["city_name"];
    $airportName = $_POST["airport_name"];

    $result = mysqli_query($conn, "INSERT INTO `citys`(`city_name`, `city_airport_name`) VALUES ('$cityName', '$airportName')");

    if($result){
        $_SESSION['message'] = "City added successfully.";
        $_SESSION['message_type'] = "success";
        header("Location: ../cities.php");
    }else{
        $_SESSION['message'] = "Something went wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: ../create-city.php");
    }

}

//for booking the ticket
if(isset($_POST["bookingBtn"])){
    
    $flight_id = $_POST["flight_id"];
    $user_id = $_POST["user_id"];
    $doj = $_POST["doj"];
    $user_name = $_POST["user_name"];
    $user_age = $_POST["user_age"];
    $user_gender = $_POST["user_gender"];
    $user_phone = $_POST["user_phone"];
    $user_email = $_POST["user_email"];
    $ticket_price = $_POST["ticket_price"];
    $payment_method = $_POST["payment_method"];
    $class = $_POST["class"];
    $status = 1;

    if($payment_method != "Select Payment Method"){
    //fetching flight data    
    $flightResult = mysqli_query($conn, "SELECT * FROM `flights_schedule` WHERE flight_id='$flight_id' AND schedule_date='$doj'");

    if(mysqli_num_rows($flightResult) > 0){
        $flightRow = mysqli_fetch_assoc($flightResult);
        $schedule_id = $flightRow["schedule_id"];
        $economy_seat = $flightRow["economy_seat"];
        $ebussiness_seat = $flightRow["bussiness_seat"];
        //updating seat in flight_schedule table
        if($class == "economy"){
            if($economy_seat != 0){
                $economy_seat = $economy_seat - 1;
                $flightUpade = mysqli_query($conn, "UPDATE `flights_schedule` SET `economy_seat`='$economy_seat' WHERE flight_id='$flight_id'");
                //genrate seat number
                $seatNumber = rand(1, $economy_seat)."E";
            }else{
                $economy_seat = $economy_seat;
            }
        }else{
            if($ebussiness_seat != 0){
                $ebussiness_seat = $ebussiness_seat - 1;
                $flightUpade = mysqli_query($conn, "UPDATE `flights_schedule` SET `bussiness_seat`='$ebussiness_seat' WHERE flight_id='$flight_id'");
                //genrate seat number
                $seatNumber = rand(1, $ebussiness_seat)."B";
            }else{
                $ebussiness_seat = $ebussiness_seat;
            }
        }
        if($payment_method == "cash"){
            // now inserting data for ticket
        $ticketResult = mysqli_query($conn, "INSERT INTO `tickets`(`user_id`, `flight_id`, `schedule_id`, `date_of_travel`, `user_name`, `class`, `ticket_price`, `seat_number`, `payment_method`, `status`) VALUES ('$user_id','$flight_id','$schedule_id','$doj','$user_name','$class','$ticket_price','$seatNumber','$payment_method','$status')");
        //using this we can get the id of the last inserted data in the table.
        $id = base64_encode(urlencode(mysqli_insert_id($conn)));

        if($ticketResult){
            $_SESSION['message'] = "Ticket Booked";
            $_SESSION['message_type'] = "success";
            header("Location: /booked.php?id=$id");
        }else{
            $_SESSION['message'] = "Something Went Wrong!";
            $_SESSION['message_type'] = "danger";
            header("Location: /booked.php?id=$id");
        }
        }else if($payment_method == "upi"){
            $_SESSION['message'] = "This method is not available right now..";
            $_SESSION['message_type'] = "success";
            header("Location: /booking.php?flight_id=".base64_encode(urlencode($flight_id))."&class=".base64_encode(urlencode($class))."&id=".base64_encode(urlencode($doj)));
        }
    
    }else{
        $_SESSION['message'] = "Flight not available.";
        $_SESSION['message_type'] = "danger";
        header("Location: /");
    }
    }else{
        $_SESSION['message'] = "Invalid Payment Method..";
        $_SESSION['message_type'] = "danger";
        header("Location: /booking.php?flight_id=".base64_encode(urlencode($flight_id))."&class=".base64_encode(urlencode($class))."&id=".base64_encode(urlencode($doj)));
    }


}

//updating flight schedule
if(isset($_POST["updateScheduleBtn"])){

    $scheduleId= $_POST["schedule_id"];
    $flightNumber = $_POST["flight_number"];
    $doj = $_POST["schedule_date"];
    $eSeat = $_POST["economy_seat"];
    $bSeat = $_POST["business_seat"];

    $result = mysqli_query($conn, "UPDATE `flights_schedule` SET `flight_id`='[value-2]',`economy_seat`='[value-3]',`bussiness_seat`='[value-4]',`status`='[value-5]',`schedule_date`='[value-6]' WHERE schedule_id='$scheduleId'");
}

//inserting enquires data into enquries table
if(isset($_POST["supportBtn"])){

    $userName = $_POST["user_name"];
    $userEmail = $_POST["user_email"];
    $userMessage = $_POST["user_message"];

    if(isset($_SESSION['userLogged']) && isset($_SESSION['userLogged']) == true){
        $userId = $_SESSION['userId'];
    }else{
        $userId = 0;
    }

    $result = mysqli_query($conn, "INSERT INTO `enquires`(`user_id`, `user_name`, `user_email`, `user_message`) VALUES ('$userId','$userName','$userEmail','$userMessage')");

    if($result){
        $_SESSION['message'] = "Thank You! Our Team will contact you soon..";
        $_SESSION['message_type'] = "success";
        header("Location: /contact.php");
    }else{
        $_SESSION['message'] = "Some Error Ocur! Try after some time.";
        $_SESSION['message_type'] = "danger";
        header("Location: /contact.php");
    }

}

//inserting and updating data into settings table
if(isset($_POST["settingsBtn"])){

    $websiteName = $_POST["website_name"];
    $websiteTitle = $_POST["website_title"];
    $supportContact = $_POST["support_contact"];
    $supportEmail = $_POST["support_email"];
    $data = $_POST["insert"];
    $eseat = $_POST["economy_seat"];
    $bseat = $_POST["business_seat"];

    if($data == 1){
        $result = mysqli_query($conn, "INSERT INTO `settings`(`website_name`, `website_title`, `support_number`, `support_email`, `economy_seat`, `business_seat`) VALUES ('$websiteName','$websiteTitle','$supportContact','$supportEmail','$eseat','$bseat')");
    }else{
        $result = mysqli_query($conn, "UPDATE `settings` SET `website_name`='$websiteName',`website_title`='$websiteTitle',`support_number`='$supportContact',`support_email`='$supportEmail',`economy_seat`='$eseat',`business_seat`='$bseat' WHERE id=1");
    }

    if($result){
        $data == 1 ? $_SESSION['message'] = "Settings Inserted Successfully!" : $_SESSION['message'] = "Settings Updated Successfully!";
        $_SESSION['message_type'] = "success";
        header("Location: ../settings.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: ../settings.php");
    }

}

//updating flights data
if(isset($_POST["updateFlightBtn"])){
    $id = $_POST["id"];
    $arrivalTime = $_POST["arrival_time"];
    $departureTime = $_POST["departure_time"];
    $duration = $_POST["duration"];
    $economyPrice = $_POST["economy_price"];
    $businessPrice = $_POST["business_price"];
    $stop = $_POST["flight_stop"];
    $status = $_POST["flight_status"] == "active" ? 1 : 0;

    $result = mysqli_query($conn, "UPDATE `flights` SET `arrival_time`='$arrivalTime',`departure_time`='$departureTime',`duration`='$duration',`economy_price`='$economyPrice',`bussiness_price`='$businessPrice',`flight_stop`='$stop',`status`='$status' WHERE flight_id='$id'");

    if($result){
         $_SESSION['message'] = "Flight Record Update Successfully";
        $_SESSION['message_type'] = "success";
        header("Location: ../flights.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: ../edit-flights.php?id=".base64_encode(urlencode($id)));
    }

}

//updating user info or profile
if(isset($_POST["profileBtn"])){

    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $state = $_POST["state"];
    $pincode = $_POST["pincode"];
    $dob = $_POST["dob"];
    $id = $_POST["id"];

    // echo $fname, $lname, $phone, $address, $state, $pincode, $dob, $id;
    // die;

    $result = mysqli_query($conn, "UPDATE `users` SET `first_name`='$fname',`last_name`='$lname',`phone`='$phone',`address`='$address',`state`='$state',`pincode`='$pincode',`dob`='$dob' WHERE user_id='$id'");

    if($result){
        $_SESSION['message'] = "Profile Updated Successfully";
        $_SESSION['message_type'] = "success";
        header("Location: /profile.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: /profile.php");
    }
}


//updating flight schedule data
if(isset($_POST["updateScheduleBtn"])){
    $id = $_POST["id"];
    $eseat = $_POST["economy_seat"];
    $bseat = $_POST["business_seat"];
    $status = $_POST["flight_status"] == "active" ? 1 : 0;
    $doj = $_POST["schedule_date"];

    $result = mysqli_query($conn, "UPDATE `flights_schedule` SET `economy_seat`='$eseat',`bussiness_seat`='$bseat',`status`='$status',`schedule_date`='$doj' WHERE schedule_id='$id'");

    if($result){
        $_SESSION['message'] = "Schedule Updated Successfully";
        $_SESSION['message_type'] = "success";
        header("Location: ../flights-schedule.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: ../edit-flights-schedule.php?id=".base64_encode(urlencode($id)));
    }
}


//adding airline data into airline table
if(isset($_POST["airlineBtn"])){

    $name = $_POST["airline_name"];
    $sPrice = $_POST["starting_price"];
    $rating = $_POST["airline_rating"];
    $status = $_POST["airline_status"] == "active" ? 1 : 0;
    if($_FILES["arrival_image"]["size"] > 0){
        $image= $_FILES["arrival_image"]["name"];

        $imageFileType = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if($imageFileType != 'jpg' && $imageFileType != 'jpeg' && $imageFileType != 'png'){
            $_SESSION['message'] = "Image Should be JPG, JPEG, PNG Only";
            $_SESSION['message_type'] = "danger";
            header("Location: ../create-airlines.php");
        }

        $path = "assets/images/airline-icon/";
        $imgExt = pathinfo($image, PATHINFO_EXTENSION);
        $filename = time().'.'.$imgExt;
        $finalImage = $path.$filename;
    }else{
        $finalImage= NULL;
    }

    $result = mysqli_query($conn, "INSERT INTO `airlines`(`airline_name`, `airline_image`, `starting_price`, `airline_rating`, `status`) VALUES ('$name', '$finalImage', '$sPrice', '$rating', $status)");

    if($result){
        if($_FILES['arrival_image']['size'] > 0){
            move_uploaded_file($_FILES['arrival_image']['tmp_name'], '../../'.$path.$filename);
        }
        $_SESSION['message'] = "Airline Record Add Successfully";
        $_SESSION['message_type'] = "success";
        header("Location: ../airlines.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: ../create-airlines.php");
    }
}


//autoschedule all flights for one day
if(isset($_POST["autoSchedule"])){
    $result = mysqli_query($conn, "SELECT * FROM `flights` WHERE status=1");
    if(mysqli_num_rows($result) > 0){
        while($row=mysqli_fetch_assoc($result)){
            $id = $row["flight_id"];
            $arrivalcity = $row["arrival_city"];
            $departurecity = $row["departure_city"];
            //fetching seats data
            $sResult = mysqli_query($conn, "SELECT * FROM `settings` WHERE id=1");
            $sRow = mysqli_fetch_assoc($sResult);
            $eseat = $sRow["economy_seat"];
            $bseat = $sRow["business_seat"];
            $status = 1;
            $currentdate = date('Y-m-d');
            $scheduleResult = mysqli_query($conn, "INSERT INTO `flights_schedule`(`flight_id`, `arrival_city`, `departure_city`, `economy_seat`, `bussiness_seat`, `status`, `schedule_date`) VALUES ('$id','$arrivalcity','$departurecity','$eseat','$bseat','$status','$currentdate')");
        }
        $_SESSION['message'] = "All Flight's Schedule Successfully";
        $_SESSION['message_type'] = "success";
        header("Location: ../flights-schedule.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: ../flights-schedule.php");
    }
}

?>