<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0"><span class="theme-color">All</span> Tickets</h3>
            </div>
            <div class="flight-data">
            <table class="table table-striped table-bordered table-hover display" id="myTable">
                <thead>
                        <tr>
                        <th scope="col">S.NO.</th>
                        <th scope="col">User Name</th>
                        <th scope="col">Class</th>
                        <th scope="col">Flight Number</th>
                        <th scope="col">Seat Number</th>
                        <th scope="col">Price</th>
                        <th scope="col">Payment Method</th>
                        <th scope="col">Travel Date</th>
                        <th scope="col">Status</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM `tickets` ORDER BY ticket_id DESC");
                    if (mysqli_num_rows($result) > 0) {
                        $sno = 0;
                        while($row=mysqli_fetch_assoc($result)){
                            $sno = $sno + 1;
                            $id = $row["flight_id"];
                            $flight = mysqli_query($conn, "SELECT flight_number FROM `flights` WHERE flight_id ='$id' AND status=1");
                            if($flight){
                                while($flightR=mysqli_fetch_assoc($flight)){
                    ?>
                        <tr>
                        <th scope="row"><?= $sno; ?></th>
                        <td><?= ucfirst($row["user_name"]); ?></td>
                        <td><?= ucfirst($row["class"]); ?></td>
                        <td><strong><?= $flightR["flight_number"]; ?></strong></td>
                        <td><?= $row["seat_number"]; ?></td>
                        <td>₹<?= number_format($row["ticket_price"]); ?></td>
                        <td class="text-uppercase"><?= $row["payment_method"]; ?></td>
                        <td><?= $row["date_of_travel"]; ?></td>
                        <td><?= $row["status"] == 1 ? "<span class='badge text-bg-success'>Booked</span>" : "<span class='badge text-bg-danger'>Not Booked</span>" ?></td>
                        </tr>
                    <?php
                                }
                            }
                        }
                    }else{
                    ?>
                    <tr>
                        <th colspan="10" class="text-center">No 🎫 Found.</th>
                    </tr>
                    <?php    
                    }
                    ?>    
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>