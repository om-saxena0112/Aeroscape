<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
// for showing any message     
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0"><span class="theme-color">Schedule</span> Flights</h3>
                <div class="d-flex">
                <?php
                    $currentdate = date('Y-m-d');
                    $sTime = date("00:00:00");
                    $cTime = date("H:i:s");
                    $counterTime = strtotime($sTime) - strtotime($cTime);
                    // echo date("H:i:s", $counterTime), $sTime, $cTime;
                    $result = mysqli_query($conn, "SELECT * FROM `flights_schedule` WHERE schedule_date='$currentdate'");
                    if(mysqli_num_rows($result) == 0){
                ?>
                <form action="includes/code.php" method="post">
                    <input type="submit" name="autoSchedule" value="Auto Schedule" id="autoSchedule" class="btn btn-outline-primary fw-bold me-2" title="Schedule All Flights">
                </form>
                <?php
                    }else{   
                ?>
                <button class="btn btn-outline-primary fw-bold me-2" disabled>Today's Flights Scheduled</button>
                <?php        
                    }
                ?>
                <a href="create-schedule-flight.php" class="btn btn-primary fw-bold">Add Schedule <i class="fa-solid fa-plus"></i></a>
                </div>
            </div>
            <div class="flight-data">
            <table class="table table-striped table-bordered table-hover display" id="myTable">
                <thead>
                        <tr>
                        <th scope="col">S.NO.</th>
                        <th scope="col">Airline Icon</th>
                        <th scope="col">Flight Number</th>
                        <th scope="col">Arrival Time</th>
                        <th scope="col">Destination Time</th>
                        <th scope="col">Arrival City</th>
                        <th scope="col">Destination City</th>
                        <th scope="col">Economy Seat</th>
                        <th scope="col">Bussiness Seat</th>
                        <th scope="col">Status</th>
                        <th scope="col">Schedule Date</th>
                        <th scope="col">Options</th>
                        </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT * FROM `flights_schedule` ORDER BY schedule_id DESC");
                    if (mysqli_num_rows($result) > 0) {
                        $sno = 0;
                        while($row=mysqli_fetch_assoc($result)){
                            $sno = $sno + 1;
                            $flightId = $row["flight_id"];
                            $flightQuery= "SELECT * FROM `flights` WHERE flight_id='$flightId'";
                            $flightResult = mysqli_query($conn,$flightQuery);
                            $flightRow = mysqli_fetch_assoc($flightResult);
                            $airId = $flightRow["airline_id"];
                            $airQuery= "SELECT * FROM `airlines` WHERE airline_id='$airId'";
                            $airResult = mysqli_query($conn,$airQuery);
                            $airRow = mysqli_fetch_assoc($airResult);
                    ?>
                        <tr>
                        <th scope="row"><?= $sno; ?></th>
                        <td class="admin-flight-icon"><img src="../<?= $airRow["airline_image"]; ?>" alt="ICON" class="img-fluid"></td>
                        <td><strong><?= $flightRow["flight_number"]; ?></strong></td>
                        <td><?= date("h:i a", strtotime($flightRow["arrival_time"])); ?></td>
                        <td><?= date("h:i a", strtotime($flightRow["departure_time"])); ?></td>
                        <td><?= ucfirst($row["arrival_city"]); ?></td>
                        <td><?= ucfirst($row["departure_city"]); ?></td>
                        <td><?= $row["economy_seat"]; ?></td>
                        <td><?= $row["bussiness_seat"]; ?></td>
                        <td><?= $row["status"] == 1 ? "<span class='badge text-bg-success'>Active</span>" : "<span class='badge text-bg-danger'>Cancelled</span>" ?></td>
                        <td><?= $row["schedule_date"]; ?></td>
                        <td><div class="d-flex gap-1">
                        <a href="edit-flights-schedule.php?id=<?=base64_encode(urlencode($row["schedule_id"]))?>" class="btn btn-primary"><i class="fa-solid fa-pen-to-square"></i></a>
                        <a href="includes/delete.php?sid=<?=base64_encode(urlencode($row["schedule_id"]))?>" class="btn btn-outline-danger"><i class="fa-solid fa-trash"></i></a>
                        </div></td>
                        </tr>
                    <?php
                        }
                    }else{
                    ?>
                    <tr>
                        <th colspan="13" class="text-center">No ✈️ Found.</th>
                    </tr>
                    <?php    
                    }
                    ?>    
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>