<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0">Create New Schedule</h3>
                <a href="flights-schedule.php" class="btn btn-danger">Back</a>
            </div>
            <div class="flight-schedule-data">
            <form action="includes/code.php" method="POST">
                <div class="container w-75 mx-auto py-4 my-4">
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <select class="form-select" id="floatingFlightNumber" name="flight_number">
                        <option selected>Select Flight Number</option>
                        <?php
                            $result = mysqli_query($conn, "SELECT airline_id,flight_number FROM `flights`");
                            if(mysqli_num_rows($result) > 0){
                                while($row=mysqli_fetch_assoc($result)){
                                    $airId = $row["airline_id"];
                                    $airResult = mysqli_query($conn, "SELECT airline_name FROM `airlines` WHERE airline_id='$airId'");
                                    if(mysqli_num_rows($airResult) > 0){
                                        while($airRow=mysqli_fetch_assoc($airResult)){
                                    
                        ?>
                        <option value="<?=$row["flight_number"]?>"><?= $row["flight_number"]; ?>, <?= ucfirst($airRow["airline_name"]); ?></option>
                        <?php
                                        }
                                    }
                                }
                            }
                        ?>
                        </select>
                        <label for="floatingFlightNumber">Flight Number</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingArrival" placeholder="Arrival City" name="arrival_city" required >
                        <label for="floatingArrival">Arrival City</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingDestination" placeholder="Destination City" name="departure_city" required>
                        <label for="floatingDestination">Destination City</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="date" class="form-control" id="floatingDate" placeholder="Enter Date" name="schedule_date" required>
                        <label for="floatingDate">Select Date</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingEconomy" placeholder="Enter Economy Seat" name="economy_seat" required>
                        <label for="floatingEconomy">Enter Economy Seat</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingBusiness" placeholder="Enter Business Seat" name="business_seat" required>
                        <label for="floatingBusiness">Enter Business Seat</label>
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" name="scheduleBtn" class="btn btn-primary customPBtn w-50">Add Schedule</button>
                </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>