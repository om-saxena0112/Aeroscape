<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0">New Flights</h3>
                <a href="flights.php" class="btn btn-danger">Back</a>
            </div>
            <div class="create-flight-data">
                <form action="includes/code.php" method="POST">
                    <div class="container w-75 mx-auto py-2">
                        <div class="d-flex gap-2 mb-3">
                        <div class="form-floating w-50">
                            <select class="form-select" id="floatingAirline" name="airline_name">
                            <option selected>Select your Airline Company</option>
                            <?php
                                $query = "SELECT airline_name FROM `airlines` WHERE status='1'";
                                $result = mysqli_query($conn, $query);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                                ?>
                            <option value="<?=$row["airline_name"];?>"><?= ucfirst($row["airline_name"]); ?></option>
                            <?php
                                    }
                                }
                            ?>
                            </select>
                            <label for="floatingAirline">Select Airline</label>
                        </div>
                        <div class="form-floating w-50">
                            <select class="form-select" id="floatingFlightStop" name="flight_stop">
                            <option selected>Select your Flight Stop</option>
                            <option value="non-stop">Non-Stop</option>
                            <option value="stop">Stop</option>
                            </select>
                            <label for="floatingFlightStop">Select Flight Stop</label>
                        </div>
                        </div>
                        <div class="flight-number-box d-flex gap-2 mb-3">
                            <div class="d-flex gap-1 w-50">
                            <div class="form-floating w-75">
                                <input type="text" class="form-control" id="floatingFlightNumber" placeholder="Flight Number" name="flight_number">
                                <label for="floatingFlightNumber">Flight Number</label>
                            </div>
                            <div class="w-25">
                            <button class="btn btn-outline-primary customPBtn" id="genrateBtn">Generate</button>
                            </div>
                            </div>
                            <div class="form-floating w-50">
                            <input type="text" class="form-control" id="floatingDuration" placeholder="Enter Duration" name="duration">
                            <label for="floatingDuration">Enter Duration</label>
                            </div>
                        </div>
                        <div class="d-flex gap-2 mb-3">
                        <div class="form-floating w-50">
                            <select class="form-select" id="floatingArrival" name="arrival_city">
                            <option selected>Select your Arrival City</option>
                            <?php
                                $query = "SELECT city_name FROM `citys`";
                                $result = mysqli_query($conn, $query);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                                ?>
                            <option value="<?=$row["city_name"];?>"><?= ucfirst($row["city_name"]); ?>, IN</option>
                            <?php
                                    }
                                }
                            ?>
                            </select>
                            <label for="floatingArrival">Arrival City</label>
                        </div>
                        <div class="form-floating w-50">
                            <select class="form-select" id="floatingDeparture" name="departure_city">
                            <option selected>Select your Departure City</option>
                            <?php
                                $query = "SELECT city_name FROM `citys`";
                                $result = mysqli_query($conn, $query);
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_assoc($result)){
                                ?>
                            <option value="<?=$row["city_name"];?>"><?= ucfirst($row["city_name"]); ?>, IN</option>
                            <?php
                                    }
                                }
                            ?>
                            </select>
                            <label for="floatingDeparture">Departure City</label>
                        </div>
                        </div>
                        <div class="d-flex gap-2 mb-3">
                        <div class="form-floating w-50">
                            <input type="time" class="form-control" id="floatingArrivalTime" placeholder="Enter Arrival Date" name="arrival_time">
                            <label for="floatingArrivalTime">Select Arrival Time</label>
                        </div>
                        <div class="form-floating w-50">
                            <input type="time" class="form-control" id="floatingDepartureTime" placeholder="Enter Departure Date" name="departure_time">
                            <label for="floatingDepartureTime">Select Departure Time</label>
                        </div>
                        </div>
                        <div class="d-flex gap-2 mb-3">
                        <div class="form-floating w-50">
                            <input type="text" class="form-control" id="floatingEconomyPrice" placeholder="Enter Economy Price" name="economy_price">
                            <label for="floatingEconomyPrice">Enter Economy Price</label>
                        </div>
                        <div class="form-floating w-50">
                            <input type="text" class="form-control" id="floatingBussinessPrice" placeholder="Enter Bussiness Price" name="bussiness_price">
                            <label for="floatingBussinessPrice">Select Bussiness Price</label>
                        </div>  
                        </div>
                        <div class="text-center">
                            <button type="submit" name="addFlightBtn" class="btn btn-primary customPBtn w-50">Add Flight</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>