<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0">Create New Airline</h3>
                <a href="airlines.php" class="btn btn-danger"><i class="fa-solid fa-arrow-left"></i> Back</a>
            </div>
            <div class="flight-schedule-data">
            <form action="includes/code.php" method="POST" enctype="multipart/form-data">
                <div class="container w-75 mx-auto py-4 my-4">
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingAirlineName" placeholder="Enter Airline Name" name="airline_name" required >
                        <label for="floatingAirlineName">Enter Airline Name</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="file" class="form-control" id="floatingImage" placeholder="Choose Image" name="arrival_image" accept="image/x-png,image/gif,image/jpeg">
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="number" class="form-control" id="floatingStarting" placeholder="Enter Starting Price" name="starting_price" required>
                        <label for="floatingStarting">Enter Starting Price</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="number" class="form-control" id="floatingRating" placeholder="Enter Airline Rating" name="airline_rating" required>
                        <label for="floatingRating">Select Airline Rating</label>
                    </div>
                </div>
                <div class="form-floating mb-3">
                    <select class="form-select" id="floatingStatus" name="airline_status" required>
                            <option>Select Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                    </select>
                    <label for="floatingStatus">Status</label>
                </div>
                <div class="text-center">
                    <button type="submit" name="airlineBtn" class="btn btn-primary customPBtn w-50">Add Airline</button>
                </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>