<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
// for showing any message     
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0">Add City</h3>
                <a href="cities.php" class="btn btn-danger"><i class="fa-solid fa-arrow-left"></i> Back</a>
            </div>
            <div class="city-data">
                <form action="includes/code.php" method="POST">
                    <div class="container w-75 mx-auto py-4 my-4">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingAirport" placeholder="Enter Airport Name" name="airport_name" required autocomplete="off">
                            <label for="floatingAirport">Enter Airport Name</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingCity" placeholder="Enter City Name" name="city_name" required autocomplete="off">
                            <label for="floatingCity">Enter City Name</label>
                        </div>
                        <div class="text-center">
                            <button type="submit" name="cityBtn" class="btn btn-primary customPBtn w-50">Add City</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>