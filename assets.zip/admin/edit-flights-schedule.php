<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
//page is only accessable when there is id
if(isset($_GET["id"])){
    $id = base64_decode(urldecode($_GET["id"]));
// for showing any message     
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
//getting data from flight schedule
$result = mysqli_query($conn, "SELECT * FROM `flights_schedule` WHERE schedule_id='$id'");
$row = mysqli_fetch_assoc($result);
//fetching flight id and other data from flight schedule 
$flightId = $row["flight_id"];
//fetching flight number from flights table with the help of flight id
$flightResult = mysqli_query($conn, "SELECT * FROM `flights` WHERE flight_id='$flightId'");
$flightRow = mysqli_fetch_assoc($flightResult);
$flightNumber = $flightRow["flight_number"];
//fecting economy seat and business seat from settings
$sResult = mysqli_query($conn, "SELECT * FROM `settings` WHERE id=1");
$sRow = mysqli_fetch_assoc($sResult);
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0">Edit Flight Schedule</h3>
                <a href="flights-schedule.php" class="btn btn-danger"><i class="fa-solid fa-arrow-left"></i> Back</a>
            </div>
            <div class="flight-data">
            <form action="includes/code.php" method="POST">
                <div class="container w-75 mx-auto py-4 my-4">
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingFlightNo" placeholder="Enter Flight Number" name="flight_number" value="<?= $flightNumber ?>" disabled>
                        <label for="floatingFlightNo">Flight Number</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="number" class="form-control" id="floatingEconomy" placeholder="Enter Economy Seat" name="economy_seat" min="0" max="<?= $sRow["economy_seat"] ?>"  value="<?= $row["economy_seat"]; ?>">
                        <label for="floatingEconomy">Enter Economy Seat(Max Seat Quantity: <?= $sRow["economy_seat"] ?>)</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="number" class="form-control" id="floatingBusiness" placeholder="Enter Business Seat" name="business_seat" min="0" max="<?= $sRow["business_seat"] ?>" value="<?= $row["bussiness_seat"]; ?>">
                        <label for="floatingBusiness">Enter Business Seat(Max Seat Quantity: <?= $sRow["business_seat"] ?>)</label>
                    </div>
                    <div class="form-floating w-50">
                        <select class="form-select" id="floatingStatus" name="flight_status" required>
                            <option <?= $row["status"] == "" ? "selected" : "" ?>>Select Status</option>
                            <option value="active" <?= $row["status"] == 1 ? "selected" : "" ?>>Active</option>
                            <option value="inactive" <?= $row["status"] == 0 ? "selected" : "" ?>>Inactive</option>
                        </select>
                        <label for="floatingStatus">Status</label>
                </div>
                </div>
                <div class="form-floating mb-3">
                        <input type="date" class="form-control" id="floatingDate" placeholder="Enter Schedule Date" name="schedule_date" value="<?= $row["schedule_date"]; ?>">
                        <label for="floatingDate">Enter Schedule Date</label>
                </div>
                <input type="hidden" name="id" value="<?= $id; ?>">
                <div class="text-center">
                    <button type="submit" name="updateScheduleBtn" class="btn btn-primary customPBtn w-50">Update Flight schedule</button>
                </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    $_SESSION['message'] = "Access Denied!";
    $_SESSION['message_type'] = "danger";
    header("Location: /admin/");
}
}else{
    header("Location: /admin/login.php");
}
?>