<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
// for showing any message     
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
//using this variable to check whether admin is putting data for first time or updating the existing data
$dataCount = 0;
$result = mysqli_query($conn, "SELECT * FROM `settings` WHERE id=1");
if(mysqli_num_rows($result) == 0){
    $dataCount = 1;
}
$row = mysqli_fetch_assoc($result);
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0"><span class="theme-color">All</span> Settings</h3>
            </div>
            <div class="settings-data">
                <form action="includes/code.php" method="POST">
                    <div class="py-4 my-4">
                        <h5 class="mb-3 pb-2 border-bottom">Website Settings</h5>
                        <div class="d-flex gap-2">
                        <div class="form-floating w-50 mb-3">
                            <input type="text" class="form-control" id="floatingWebsite" placeholder="Enter Website Name" name="website_name" value="<?= $dataCount == 0 ? $row["website_name"] : "" ?>" required autocomplete="off">
                            <label for="floatingWebsite">Enter Website Name</label>
                        </div>
                        <div class="form-floating w-50 mb-3">
                            <input type="text" class="form-control" id="floatingTitle" placeholder="Enter Website Title" name="website_title" value="<?= $dataCount == 0 ? $row["website_title"] : "" ?>" required autocomplete="off">
                            <label for="floatingTitle">Enter Website Title</label>
                        </div>
                        </div>
                        <h5 class="mb-3 pb-2 border-bottom">Contact Settings</h5>
                        <div class="d-flex gap-2">
                        <div class="form-floating w-50 mb-3">
                            <input type="number" class="form-control" id="floatingContact" placeholder="Enter Support Contact Number" name="support_contact" value="<?= $dataCount == 0 ? $row["support_number"] : "" ?>" required autocomplete="off">
                            <label for="floatingContact">Enter Support Contact Number</label>
                        </div>
                        <div class="form-floating w-50 mb-3">
                            <input type="text" class="form-control" id="floatingEmail" placeholder="Enter Support Email" name="support_email" value="<?= $dataCount == 0 ? $row["support_email"] : "" ?>" required autocomplete="off">
                            <label for="floatingEmail">Enter Support Email</label>
                        </div>
                        </div>
                        <h5 class="mb-3 pb-2 border-bottom">Auto Schedule Settings</h5>
                        <div class="d-flex gap-2">
                        <div class="form-floating w-50 mb-3">
                            <input type="number" class="form-control" id="floatingEconomy" placeholder="Enter Economy Seat" name="economy_seat" value="<?= $dataCount == 0 ? $row["economy_seat"] : "" ?>" required>
                            <label for="floatingEconomy">Enter Economy Seat</label>
                        </div>
                        <div class="form-floating w-50 mb-3">
                            <input type="text" class="form-control" id="floatingBusiness" placeholder="Enter Bussiness Seat" name="business_seat" value="<?= $dataCount == 0 ? $row["business_seat"] : "" ?>" required>
                            <label for="floatingBusiness">Enter Bussiness Seat</label>
                        </div>
                        </div>
                        <div class="text-center">
                            <input type="hidden" name="insert" value="<?= $dataCount; ?>">
                            <button type="submit" name="settingsBtn" class="btn btn-primary customPBtn w-50"><?= $dataCount == 0 ? "Update Settings" : "Insert Settings" ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    header("Location: /admin/login.php");
}
?>