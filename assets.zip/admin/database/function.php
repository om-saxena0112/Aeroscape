<?php

function fetchData($tableName){
    global $conn;
    $result = mysqli_query($conn, "SELECT * FROM `$tableName`");
    $count = mysqli_num_rows($result);
    return $count;
}

function fetchTodayData($tableName, $todayDate){
    global $conn;
    $result = mysqli_query($conn, "SELECT * FROM `$tableName` WHERE schedule_date='$todayDate'");
    $count = mysqli_num_rows($result);
    return $count;
}

function fetchDataByStatus($tableName){
    global $conn;
    $result = mysqli_query($conn, "SELECT * FROM `$tableName` WHERE status='0'");
    $count = mysqli_num_rows($result);
    return $count;
}

function settings($tableColumn){
    global $conn;
    $result = mysqli_query($conn, "SELECT $tableColumn FROM `settings` WHERE id=1");
    $row = mysqli_fetch_assoc($result);
    return $row["$tableColumn"];
}

function fetchColumnIncome($tableName, $tableColumn){
    global $conn;
    $result = mysqli_query($conn, "SELECT $tableColumn FROM `$tableName`");
    $price = 0;
    While($row = mysqli_fetch_assoc($result)){
        $price = $price + (int)$row["$tableColumn"];
    }
    return $price;
}

function fetchTodayIncome($tableName, $tableColumn, $todayDate){
    global $conn;
    $result = mysqli_query($conn, "SELECT $tableColumn FROM `$tableName` WHERE date_of_travel='$todayDate'");
    $price = 0;
    While($row = mysqli_fetch_assoc($result)){
        $price = $price + (int)$row["$tableColumn"];
    }
    return $price;
}

function TimeCounter(){
    $sTime = date("00:00:00");
    $cTime = date("H:i:s");
    $counterTime = strtotime($cTime) - strtotime($sTime);
    return $counterTime;
}

?>