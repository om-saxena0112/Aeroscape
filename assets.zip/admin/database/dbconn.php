<?php

//setting time zone for server
date_default_timezone_set('Asia/Kolkata');
$time=date("Y-m-d H:i:s");
$serverTime=date("d/m/Y h:i:s A");
//connecting database with website
define('DB_SERVERNAME', 'sql107.infinityfree.com');
define('DB_USERNAME', 'if0_35469177');
define('DB_PASSWORD', 'hqnbCeNcm7cVkhF');
define('DB_DATABASE', 'if0_35469177_flight_db');

$conn = mysqli_connect(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

if(!$conn){
    die("Error Occur while connecting to database ". mysqli_connect_error());
}

?>