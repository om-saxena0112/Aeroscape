<?php include "includes/admin_header.php";
if(isset($_SESSION['adminLogged']) && $_SESSION['adminLogged'] == true){
//page is only accessable when there is id
if(isset($_GET["id"])){
    $id = base64_decode(urldecode($_GET["id"]));
// for showing any message     
if(isset($_SESSION['message'])){
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
unset($_SESSION['message']);
}
//getting data from flight schedule
$result = mysqli_query($conn, "SELECT * FROM `flights` WHERE flight_id='$id'");
$row = mysqli_fetch_assoc($result);
//fetching flight id and other data from flight schedule 
$flightId = $row["flight_id"];
$doj = $row["schedule_date"];
$eSeat = $row["economy_seat"];
$bSeat = $row["bussiness_seat"];
?>
<div class="container my-4">
    <div class="card shadow py-3">
        <div class="card-body">
            <div class="admin-flight-heading pb-2 mb-2">
                <h3 class="mb-0">Edit Flight</h3>
                <a href="flights.php" class="btn btn-danger"><i class="fa-solid fa-arrow-left"></i> Back</a>
            </div>
            <div class="flight-data">
            <form action="includes/code.php" method="POST">
                <div class="container w-75 mx-auto py-4 my-4">
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="hidden" name="schedule_id" value="<?= $id; ?>">
                        <?php
                            $query = "SELECT * FROM `flights` WHERE flight_id='$flightId'";
                            $result = mysqli_query($conn, $query);
                            if(mysqli_num_rows($result) > 0){
                                $row=mysqli_fetch_assoc($result);
                            ?>
                        <input type="text" class="form-control" id="floatingFlightNo" placeholder="Enter Flight Number" name="flight_number" value="<?= $row["flight_number"] ?>" disabled>
                        <label for="floatingFlightNo">Flight Number</label>
                        <?php
                            }
                        ?>
                    </div>
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingArrival" placeholder="Arrival City" name="arrival_city" value="<?= ucfirst($row["arrival_city"]); ?>" disabled>
                        <label for="floatingArrival">Arrival City</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingDeparture" placeholder="Destination City" name="departure_city" value="<?= ucfirst($row["departure_city"]); ?>" disabled>
                        <label for="floatingDeparture">Destination City</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="time" class="form-control" id="floatingATime" placeholder="Enter Arrival Time" name="arrival_time" value="<?= $row["arrival_time"]; ?>">
                        <label for="floatingATime">Enter Arrival Time</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="time" class="form-control" id="floatingDTime" placeholder="Enter Departure Time" name="departure_time" value="<?= $row["departure_time"]; ?>">
                        <label for="floatingDTime">Enter Departure time</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="number" class="form-control" id="floatingEconomy" placeholder="Enter Economy Price" name="economy_price" value="<?= $row["economy_price"]; ?>">
                        <label for="floatingEconomy">Enter Economy Price</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                    <div class="form-floating w-50">
                        <input type="number" class="form-control" id="floatingBusiness" placeholder="Enter Business Price" name="business_price" value="<?= $row["bussiness_price"]; ?>">
                        <label for="floatingBusiness">Enter Business Price</label>
                    </div>
                    <div class="form-floating w-50">
                        <input type="text" class="form-control" id="floatingDuration" placeholder="Enter Duration" name="duration" value="<?= $row["duration"]; ?>">
                        <label for="floatingDuration">Enter Duration</label>
                    </div>
                </div>
                <div class="d-flex gap-2 mb-3">
                <div class="form-floating w-50">
                        <select class="form-select" id="floatingStatus" name="flight_status" required>
                            <option <?= $row["status"] == "" ? "selected" : "" ?>>Select Status</option>
                            <option value="active" <?= $row["status"] == 1 ? "selected" : "" ?>>Active</option>
                            <option value="inactive" <?= $row["status"] == 0 ? "selected" : "" ?>>Inactive</option>
                        </select>
                        <label for="floatingStatus">Status</label>
                </div>
                <div class="form-floating w-50">
                        <select class="form-select" id="floatingStop" name="flight_stop" required>
                            <option <?= $row["status"] == "" ? "selected" : "" ?>>Select Stop</option>
                            <option value="<?= $row["flight_stop"]; ?>" <?= $row["flight_stop"] == "stop" ? "selected" : "" ?>><?= $row["flight_stop"] ?></option>
                            <option value="<?= $row["flight_stop"]; ?>" <?= $row["flight_stop"] == "non-stop" ? "selected" : "" ?>><?= $row["flight_stop"] ?></option>
                        </select>
                        <label for="floatingStop">Stop</label>
                </div>
                </div>
                <input type="hidden" name="id" value="<?= $id; ?>">
                <div class="text-center">
                    <button type="submit" name="updateFlightBtn" class="btn btn-primary customPBtn w-50">Update Flight</button>
                </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<?php
include "includes/admin_footer.php";
}else{
    $_SESSION['message'] = "Access Denied!";
    $_SESSION['message_type'] = "danger";
    header("Location: /admin/");
}
}else{
    header("Location: /admin/login.php");
}
?>