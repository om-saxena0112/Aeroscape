<?php include("includes/header.php"); ?>

<?php
if (isset($_SESSION['message'])) {
?>
    <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php
    unset($_SESSION['message']);
}
?>

<div class="flight-search-box container-fluid py-4  mb-2">
    <div class="search-box">
        <form action="flights.php" method="POST">
            <?php
            include "includes/functions.php";
            if (isset($_POST['flightBtn']) || isset($_POST['updateFlightBtn'])) {
                if (isset($_POST["flightBtn"])) {
                    $arrivalCity = $_POST["arrival"];
                    $departureCity = $_POST["departure"];
                    $class = $_POST["class"];
                    $doj = $_POST["doj"];
                    if ($arrivalCity == $departureCity) {
                        $_SESSION['message'] = "Arrival & Destination cannot be same..";
                        $_SESSION['message_type'] = "danger";
                        header("Location: /");
                    }
                } else if (isset($_POST["updateFlightBtn"])) {
                    $arrivalCity = $_POST["flight_arrival"];
                    $departureCity = $_POST["flight_departure"];
                    $class = $_POST["flight_class"];
                    $doj = $_POST["flight_doj"];
                    if($arrivalCity == $departureCity){
                        $_SESSION['message'] = "Arrival & Destination cannot be same..";
                        $_SESSION['message_type'] = "danger";
                        header("Location: /");
                    }
                }
            ?>
                <div class="w-75 mx-auto py-1">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <form action="<?= $_SERVER['PHP_SELF']; ?>" method="POST">
                            <div class="form-floating w-50">
                                <select class="form-select" id="floatingArival" name="flight_arrival" required>
                                    <option <?= $arrivalCity == "" ? "selected" : "" ?>>Select your Arrival</option>
                                    <?php
                                    $query = "SELECT city_name FROM `citys`";
                                    $result = mysqli_query($conn, $query);
                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            $cityName = $row["city_name"];
                                    ?>
                                            <option value="<?= $cityName; ?>" <?= $arrivalCity == $cityName ? "selected" : "" ?>><?= ucfirst($cityName); ?>, IN</option>
                                    <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <label for="floatingArival">From</label>
                            </div>
                            <div class="form-floating w-50">
                                <select class="form-select" id="floatingDestination" name="flight_departure" required>
                                    <option <?= $departureCity == "" ? "selected" : "" ?>>Select your Destination</option>
                                    <?php
                                    $query = "SELECT city_name FROM `citys`";
                                    $result = mysqli_query($conn, $query);
                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            $cityName = $row["city_name"];
                                    ?>
                                            <option value="<?= $cityName; ?>" <?= $departureCity == $cityName ? "selected" : "" ?>><?= ucfirst($cityName); ?>, IN</option>
                                    <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <label for="floatingDestination">To</label>
                            </div>
                            <div class="form-floating w-50">
                                <select class="form-select" id="floatingTicketType" name="flight_class" value="<?= $class; ?>" required>
                                    <option <?= $class == "" ? "selected" : "" ?>>Select your Class</option>
                                    <option value="economy" <?= $class == "economy" ? "selected" : "" ?>>Economy</option>
                                    <option value="bussiness" <?= $class == "bussiness" ? "selected" : "" ?>>Business</option>
                                </select>
                                <label for="floatingTicketType">From</label>
                            </div>
                            <div class="form-floating w-50">
                                <input type="date" class="form-control" id="floatingDate" placeholder="Enter Date" name="flight_doj" value="<?= $doj; ?>" required>
                                <label for="floatingDate">Select Date</label>
                            </div>
                            <button type="submit" class="btn btn-secondary w-25 text-uppercase" name="updateFlightBtn">Search</button>
                        </form>
                    </div>
                </div>
        </form>
    </div>
</div>

<div class="flight-data container-fluid mb-4">
    <div class="flight-container">
        <div class="filter">
            <div class="card shadow py-4">
                <div class="airline-name-list w-75 mx-auto mb-3">
                    <h6 class="fw-bold">Airlines</h6>
                    <ul>
                        <?php
                        $airResult = mysqli_query($conn, "SELECT airline_name FROM `airlines` WHERE status=1");
                        while ($airRow = mysqli_fetch_assoc($airResult)) {
                        ?>
                            <li>
                                <div class="d-flex justify-content-between">
                                    <div class="airline-name">
                                        <input class="form-check-input mt-0 me-1" type="checkbox"> <span class="text-capitalize"><?= $airRow["airline_name"] ?></span>
                                    </div>
                                    <div class="airline-price">₹2500</div>
                                </div>
                            </li>
                        <?php
                        }
                        ?>
                    </ul>
                </div>
                <div class="airline-stop w-75 mx-auto mb-3">
                    <h6 class="fw-bold">Stop From <?= $arrivalCity == "delhi" ? "New Delhi" : ucfirst($arrivalCity); ?></h6>
                    <ul>
                        <li>
                            <div class="d-flex justify-content-between">
                                    <div class="airline-name">
                                        <input class="form-check-input mt-0 me-1" type="checkbox"> <span class="text-capitalize">Non-Stop</span>
                                    </div>
                                    <div class="airline-price">₹13,500</div>
                            </div>
                        </li>
                        <li>
                            <div class="d-flex justify-content-between">
                                    <div class="airline-name">
                                        <input class="form-check-input mt-0 me-1" type="checkbox"> <span class="text-capitalize">1 Stop</span>
                                    </div>
                                    <div class="airline-price">₹9,800</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="flight-data-list">
            <div class="flight-citys">
                <h4 class="text-light fw-bold">Flights From <span class="text-capitalize"><?= $arrivalCity == "delhi" ? "New Delhi" : $arrivalCity; ?></span> to <span class="text-capitalize"><?= $departureCity == "delhi" ? "New Delhi" : $departureCity; ?></span></h4>
            </div>
            <?php
                //checking whether flight are available between arrival and destination city
                $scheduleResult = mysqli_query($conn, "SELECT * FROM `flights_schedule` WHERE arrival_city='$arrivalCity' AND departure_city='$departureCity' AND schedule_date='$doj' AND status=1");
                if (mysqli_num_rows($scheduleResult) > 0) {
                    //using this variable to overcome the else statement duplicating problem
                    $dataCount = 1;
                    while ($scheduleRow = mysqli_fetch_assoc($scheduleResult)) {
                        //fetching flight id to check flight schedule
                        $flightId = $scheduleRow["flight_id"];
                        $result = mysqli_query($conn, "SELECT * FROM `flights` WHERE arrival_city='$arrivalCity' AND departure_city='$departureCity' AND flight_id='$flightId' AND status=1");
                        $row = mysqli_fetch_assoc($result);
                        $airId = $row["airline_id"];
                        //fetching airline name and airline image
                        $airResult = mysqli_query($conn, "SELECT * FROM `airlines` WHERE airline_id='$airId' AND status=1");
                        if(mysqli_num_rows($airResult) > 0){
                        $airRow = mysqli_fetch_assoc($airResult);
                        if (mysqli_num_rows($result) > 0) {
                            $economySeat = $scheduleRow["economy_seat"];
                            $businessSeat = $scheduleRow["bussiness_seat"];
            ?>
                        <div class="card shadow py-1 mb-3">
                            <div class="card-body">
                                <div class="flight-info">
                                    <div class="airline-info">
                                        <div class="airline-logo">
                                            <img src="<?= $airRow["airline_image"]; ?>" class="img-fluid" alt="AIRLINE-ICON">
                                        </div>
                                        <div class="other-info">
                                            <h6 class="fw-bold text-capitalize"><?= $airRow["airline_name"]; ?></h6>
                                            <p class="mb-0"><?= $row["flight_number"]; ?></p>
                                        </div>
                                    </div>
                                    <div class="arrival-info">
                                        <div class="arrival-time">
                                            <h5 class="fw-bold"><?= date('g:ia', strtotime($row["arrival_time"])); ?></h5>
                                            <p class="mb-0 text-capitalize"><?= $row["arrival_city"] == "delhi" ? "New Delhi" : $row["arrival_city"]; ?></p>
                                        </div>
                                    </div>
                                    <div class="stop-info">
                                        <p class="text-center mb-1"><?= $row["duration"]; ?></p>
                                        <hr class="border border-<?php echo $row["flight_stop"] == "non-stop" ? "success" : "danger"; ?> border-3 opacity-75">
                                        <p class="mb-1"><?= $row["flight_stop"]; ?></p>
                                    </div>
                                    <div class="destination-info">
                                        <div class="destination-time">
                                            <h5 class="fw-bold"><?= date('g:ia', strtotime($row["departure_time"])); ?></h5>
                                            <p class="mb-0 text-capitalize"><?= $row["departure_city"] == "delhi" ? "New Delhi" : $row["departure_city"]; ?></p>
                                        </div>
                                    </div>
                                    <div class="price-info">
                                        <?php
                                        //economy price is going to increase if seat is less than 10
                                        if ($economySeat < 10) {
                                            $ePrice = $row["economy_price"] + 1000;
                                        } else {
                                            $ePrice = $row["economy_price"];
                                        }
                                        //business price is going to increase if seat is less than 10
                                        if ($businessSeat < 10) {
                                            $bPrice = $row["bussiness_price"] + 1500;
                                        } else {
                                            $bPrice = $row["bussiness_price"];
                                        }
                                        ?>
                                        <h5 class="fw-bold">₹<?= $class == "economy" ? number_format($ePrice) : number_format($bPrice); ?></h5>
                                        <p class="text-center mb-1">per adult</p>
                                    </div>
                                    <div class="flight-details">
                                        <?php
                                        //checking whether the date or time is correct according to the current date and time in order to book the ticket
                                        $DOJ = date($doj);
                                        $arrivalTime = strtotime($row["arrival_time"]);
                                        $arrivalTime = date("H:i:s", $arrivalTime);
                                        $currentTime = date("H:i:s");
                                        //  echo $arrivalTime, ",", $currentTime;
                                        $attr = "";
                                        $tooltip = "Not Yet Departured.";
                                        $class_seat = $class == "economy" ? $economySeat : $businessSeat;
                                        if ($DOJ >= $currentDate) {
                                            if ($DOJ == $currentDate) {
                                                if ($arrivalTime <= $currentTime) {
                                                    $tooltip = "Departured.";
                                                    $attr = "disabled";
                                                }
                                            } else if ($class_seat == 0) {
                                                $tooltip = "No Seat Left.";
                                                $attr = "disabled";
                                            }
                                        } else {
                                            $tooltip = "Departured.";
                                            $attr = "disabled";
                                        }
                                        //hiding booking page url if button is disabled.
                                        if($attr != "disabled"){
                                        ?>
                                        <button class="btn btn-primary mb-2" title="<?= $tooltip; ?>" <?= $attr; ?>><a href="booking.php?flight_id=<?= base64_encode(urlencode($row["flight_id"])); ?>&class=<?= $class == "economy" ? base64_encode(urlencode("economy")) : base64_encode(urlencode("bussiness")) ?>&id=<?= base64_encode(urlencode($doj)); ?>" class="text-white">Book Ticket</a></button>
                                        <?php
                                        }else{
                                        ?>
                                        <button class="btn btn-outline-primary mb-2" title="<?= $tooltip; ?>" <?= $attr; ?>><?= $tooltip; ?></button>
                                        <?php
                                        }
                                        ?>
                                        <p class="text-primary more-detail">View Flight Details</p>    
                                    </div>
                                </div>
                            </div>
                            <div class="hidden-info card mb-3">
                                <div class="card-body">
                                    <ul class="nav nav-pills border mb-3" id="pills-tab" role="tablist">
                                        <li class="nav-item border" role="presentation">
                                            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Flight Details</button>
                                        </li>
                                        <li class="nav-item border" role="presentation">
                                            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Flight Summary</button>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
                                            <div class="flight-details border">
                                                <div class="flight-location border">
                                                    <h5 class="mb-0 px-2 py-2"><?= $row["arrival_city"] == "delhi" ? "New Delhi" : ucfirst($row["arrival_city"]); ?> to <?= $row["departure_city"] == "delhi" ? "New Delhi" : ucfirst($row["departure_city"]); ?>, <?= ModifyDate($doj); ?></h5>
                                                </div>
                                                <div class="flight-other-info px-2 py-2">
                                                    <div class="flight-other-icon mb-3">
                                                        <div class="airline-logo">
                                                            <img src="<?= $airRow["airline_image"]; ?>" class="img-fluid" alt="AIRLINE-ICON">
                                                        </div>
                                                        <div class="other-info">
                                                            <h6 class="fw-bold mb-0 me-2"><?= $airRow["airline_name"]; ?></h6>
                                                            <span class="mb-0">| <?= $row["flight_number"]; ?></span>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <div class="arrival-info">
                                                            <div class="arrival-time">
                                                                <h5 class="fw-bold"><?= date('g:ia', strtotime($row["arrival_time"])); ?></h5>
                                                                <p class="mb-1">Terminal 2</p>
                                                                <p class="mb-0"><?= $row["arrival_city"] == "delhi" ? "New Delhi" : ucfirst($row["arrival_city"]); ?>, India</p>
                                                            </div>
                                                        </div>
                                                        <div class="stop-info">
                                                            <p class="text-center mb-1"><?= $row["duration"]; ?></p>
                                                            <hr class="border border-<?php echo $row["flight_stop"] == "non-stop" ? "success" : "danger"; ?> border-3 opacity-75">
                                                            <p class="mb-1 text-center"><?= $row["flight_stop"]; ?></p>
                                                        </div>
                                                        <div class="destination-info">
                                                            <div class="destination-time">
                                                                <h5 class="fw-bold"><?= date('g:ia', strtotime($row["departure_time"])); ?></h5>
                                                                <p class="mb-1">Terminal 2</p>
                                                                <p class="mb-0"><?= ucfirst($row["departure_city"]); ?>, India</p>
                                                            </div>
                                                        </div>
                                                        <div class="customer-info">
                                                            <div class="baggage">
                                                                <h5 class="fw-bold text-uppercase">Baggage:</h5>
                                                                <p class="mb-1 text-uppercase">adult</p>
                                                            </div>
                                                            <div class="check-in">
                                                                <h5 class="fw-bold text-uppercase">Check In</h5>
                                                                <p class="mb-1 text-uppercase">15kg <span class="text-lowercase">(1 piece only)</span></p>
                                                            </div>
                                                            <div class="cabin">
                                                                <h5 class="fw-bold text-uppercase">Cabin</h5>
                                                                <p class="mb-1 text-uppercase">7kg <span class="text-lowercase">(1 piece only)</span></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                                            <div class="flight-price border">
                                                <div class="flight-price-heading border px-1 py-2">
                                                    <h5 class="mb-0">Fare Breakup</h5>
                                                </div>
                                                <div class="fare-breakup px-1 py-2">
                                                    <div class="total-fare mb-2">
                                                        <div class="fare-heading">
                                                            <h5>Total</h5>
                                                        </div>
                                                        <div class="fare">
                                                            <h5>₹<?= $class == "economy" ? number_format($row["economy_price"]) : number_format($row["bussiness_price"]); ?></h5>
                                                        </div>
                                                    </div>
                                                    <div class="base-charge">
                                                        <div class="fare-heading">
                                                            <p class="text-secondary">Base Fare</p>
                                                        </div>
                                                        <div class="fare">
                                                            <p class="text-secondary">₹<?= $class == "economy" ? number_format(taxBase($row["economy_price"])) : number_format(taxBase($row["bussiness_price"])); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="surcharge">
                                                        <div class="fare-heading">
                                                            <p class="text-secondary">Surcharges</p>
                                                        </div>
                                                        <div class="fare">
                                                            <p class="text-secondary">₹<?= $class == "economy" ? number_format(taxFee($row["economy_price"])) : number_format(taxFee($row["bussiness_price"])); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                         }else{
                        ?>
                            <div class="card shadow py-3 mb-3">
                                <div class="card-body">
                                    <h2 class="text-center"><?= "No ✈️ Schedule for Today"; ?></h2>
                                </div>
                            </div>
                <?php
                       }}else{
                ?>
                            <div class="card shadow py-3 mb-3">
                                <div class="card-body">
                                    <h2 class="text-center"><?= "No ✈️ Available for these cities"; ?></h2>
                                </div>
                            </div>
                <?php           
                       } }
                } else {
                ?>
                <div class="card shadow py-3 mb-3">
                    <div class="card-body">
                        <h2 class="text-center"><?= "No ✈️ Available for these cities"; ?></h2>
                    </div>
                </div>
        <?php
                }
            } else {
                header("Location: /");
            }
        ?>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>