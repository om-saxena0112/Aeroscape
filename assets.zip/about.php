<?php include("includes/header.php"); ?>

<div class="pageNameBox container-fluid py-4  mb-2">
    <div class="pageName">
        <h2 class="text-center">About</h2>
    </div>
</div>

<div class="about-box container-fluid mb-4">
    <div class="card about-container shadow my-3">
        <div class="card-body">
            <div class="about-info-section-1 mb-3">
                <div class="about-info-content w-75">
                    <h3 class="mb-3 fw-bold text-uppercase">What <span class="theme-color">Aero</span>scape Do?</h3>
                    <p class="mb-0">Aeroscape is a flight reservation website that helps people to find and compare flights. It aggregates information from various airlines agencies to present users with a comprehensive list of options. Users can input their travel details, such as destination and dates, and Aeroscape will display a range of available flights along with their prices. It's a handy tool for travelers looking to compare prices across different providers and make informed decisions about their travel plans.Users can search for flights by entering their departure and destination cities, along with their travel dates.Aeroscape provides a list of available flights from multiple airlines, allowing users to compare prices, flight durations, and other details to find the most suitable options.Aeroscape aims to simplify the travel planning process by offering a user-friendly platform to explore and book travel accommodations at competitive prices.</p>
                </div>
                <div class="about-info-image w-25">
                    <img src="assets/images/about-1.png" alt="ABOUT-IMAGE" class="img-fluid">
                </div>
            </div>
            <div class="about-info-section-2 mb-3">
                <div class="about-info-image w-25">
                    <img src="assets/images/about-2.png" alt="ABOUT-IMAGE" class="img-fluid">
                </div>
                <div class="about-info-content w-75">
                    <h3 class="mb-3 fw-bold text-uppercase">How Booking Works?</h3>
                    <p class="mb-0"> Users can start by entering their travel details such as destination, dates, number of passengers, and preferences. Aeroscape generates a list of available options based on the entered criteria. For flights, it displays various airlines, their prices, timings, layovers, and other pertinent details. Upon selecting a flight, users are guided through the booking process. Aeroscape allows users to review their selection, add additional services , and proceed to the payment page.Users enter their payment details and complete the transaction using various payment methods accepted by Aeroscape(credit/debit cards, net banking,  etc.). After successful payment,Users can view their ticket through their profile page.</p>
                </div>
            </div>
            <div class="about-info-section-3 mb-3">
                <div class="about-info-content w-75">
                    <h3 class="mb-3 fw-bold text-uppercase">Keeping <span class="theme-color">It </span>Simple?</h3>
                    <p class="mb-0">We come together each day to fulfill a promise of offering the single most comprehensive travel experience to users, through award-winning Mobile and Desktop solutions. With intuitive products that have the largest selection of flights , we keep customers at the center of everything we do.!</p>
                </div>
                <div class="about-info-image w-25">
                    <img src="assets/images/about-1.png" alt="ABOUT-IMAGE" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>