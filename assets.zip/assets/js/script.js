//current page
let page = location.pathname;
// page = page.split("/");

// code for showing today's date as value in booking card.
let date = new Date();

let day = date.getDate();
let month = date.getMonth() + 1;
let year = date.getFullYear();

if (month < 10) month = "0" + month;
if (day < 10) day = "0" + day;

let today = year + "-" + month + "-" + day;
// if(page[2] == ""){
if(page == "/"){
document.getElementById("floatingDate") ? document.getElementById("floatingDate").value = today : "";
}
//setting footer year using year variable.
document.querySelector("#footerYear").innerHTML = year;

// if(page[2] == ""){
if(page == "/"){
// code for typewriter effect type function
async function typeSentence(sentence, eleRef, delay = 100) {
    const letters = sentence.split("");
    let i = 0;
    while(i < letters.length) {
      await waitForMs(delay);
      $(eleRef).append(letters[i]);
      i++
    }
    return;
} 
  
function waitForMs(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

async function deleteSentence(eleRef) {
    const sentence = $(eleRef).html();
    const letters = sentence.split("");
    let i = 0;
    while(letters.length > 0) {
      await waitForMs(100);
      letters.pop();
      $(eleRef).html(letters.join(""));
    }
}

const carouselText = [
    {text: "A pleasure which also pleases your pocket."},
    {text: "From here to anywhere, your voyage starts here."},
    {text: "Your window to the world, open the Booking now."}
  ]
  
async function carousel(carouselList, eleRef) {
      var i = 0;
      while(true) {
        await typeSentence(carouselList[i].text, eleRef);
        await waitForMs(1500);
        await deleteSentence(eleRef);
        await waitForMs(500);
        i++
        if(i >= carouselList.length) {i = 0;}
      }
}

carousel(carouselText, "#custom-word");
}

//changing background color when scroll down
// if (page[2] == ''){
if (page == '/'){
$(window).scroll(function(){
  let scroll = $(window).scrollTop();
  if(scroll > 100){
    document.getElementById("navbar").classList.add("bg-white");
    document.getElementById("navbar").classList.add("shadow");
    document.getElementById("navbar-brand").classList.add("text-dark");
    document.querySelectorAll(".nav-link").forEach((Element) => {
      Element.classList.add("text-dark");
    });
  }else{
    document.getElementById("navbar").classList.remove("bg-white");
    document.getElementById("navbar").classList.remove("shadow");
    document.getElementById('navbar-brand').classList.remove("text-dark");
    document.querySelectorAll(".nav-link").forEach((Element) => {
      Element.classList.remove("text-dark");
    });
  }
});
}

// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}

//flights page code
let monthName = ['January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
let currDate = day + monthName[month - 1];
if(page[2] != ""){

  //for setting months name
  document.querySelector("#current_date") ? document.querySelector("#current_date").innerHTML = currDate : "";

  //more details pannel 
  let detailBtn = document.querySelectorAll(".more-detail");

  detailBtn.forEach((e) => {
    e.addEventListener("click", (element)=>{
      let text = element.target.innerHTML;
      if(text == "view Flight Details"){
        console.log(text);
        text.innerText = "Hide Flight Details";
      }else{
        console.log(text);
        text.innerText = "View Flight Details";
      }
      let parentContainer = element.target.parentNode.parentNode.parentNode.parentNode;
      let child = parentContainer.querySelectorAll(".hidden-info");
      child[0].classList.toggle("show");
      // console.log(child[0]);
  });
});
}

// to hide the popup message 
let alert = document.querySelector(".alert");
if(alert){
    setTimeout(() => {
        alert.classList.remove("show");
    }, 3000);
}

//datatable
$(document).ready( function () {
  $('#myTable').DataTable({
      responsive: true
  });
} );

//faq's
$(".open").click(function () {
  var container = $(this).parents(".topic");
  var answer = container.find(".answer");
  var trigger = container.find(".faq-t");

  answer.slideToggle(200);

  if (trigger.hasClass("faq-o")) {
    trigger.removeClass("faq-o");
  } else {
    trigger.addClass("faq-o");
  }

  if (container.hasClass("expanded")) {
    container.removeClass("expanded");
  } else {
    container.addClass("expanded");
  }
});

//preloader
let loading = document.getElementById("preloader");
let main = document.getElementById("main-section");
const loadFun = () =>{
    main.style.display = 'block';
    loading.style.display = 'none';
}

//navmenu button
let navbtn = document.getElementById("nav-menu");
let close = document.getElementById("navBar-close");
if(navbtn && close){
    let menuList = document.getElementById("navbarSupportedContent");
    navbtn.addEventListener("click", ()=>{
        menuList.classList.toggle("showMenu");
    });
    close.addEventListener("click", ()=>{
        menuList.classList.remove("showMenu");
    });
}

//for showing booking card on mobile view
let bookbtn = document.getElementById("booking");
if(bookbtn){
    let bcard = document.getElementById("bookingCard");
    bookbtn.addEventListener("click", (e)=>{
        e.target.style.display = "none";
        bcard.style.display = "block";
    })
}