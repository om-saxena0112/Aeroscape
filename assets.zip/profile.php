<?php include("includes/header.php");
include "includes/functions.php";
if(isset($_SESSION['userLogged']) && $_SESSION['userLogged'] == true){

//for showing message    
if (isset($_SESSION['message'])) {
    ?>
    <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
      <?= $_SESSION['message']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php 
    unset($_SESSION['message']);   
    }
?>
  
<div class="pageNameBox container-fluid py-4">
    <div class="pageName">
        <h2 class="text-center">Profile</h2>
    </div>
</div>

<div class="all-ticket container mb-4">
   <div class="all-ticket-container">
   <div class="card w-25 py-4 my-4">
    <div class="card-body">
        <div class="profile-photo mx-auto mb-3">
            <img src="assets/images/user.png" class="img-fluid" alt="PROFILE-IMAGE">
        </div>
        <div class="UserName border-bottom mb-3">
            <h4 class="text-center text-uppercase"><?= $_SESSION['fname'] ? $_SESSION['fname'] : "user" ?></h4>
        </div>
        <ul>
            <li><a href="tickets.php" class="text-uppercase">View Ticket</a></li>
            <li><a href="profile.php" class="user-active text-uppercase">Profile</a></li>
        </ul>
    </div>
   </div>
   <?php
   $id= $_SESSION['userId'];
   $result = mysqli_query($conn, "SELECT * FROM `users` WHERE user_id='$id'");
   $row = mysqli_fetch_assoc($result);
   ?>
   <div class="profile card w-75 py-4 my-4">
    <div class="card-body">
    <form action="admin/includes/code.php" method="POST">
    <div class="d-flex gap-2 mb-3">
    <div class="form-floating w-50">
    <input type="text" class="form-control" id="floatingFName" placeholder="Enter First Name" name="fname" value="<?= $row["first_name"] ?>" required>
    <label for="floatingFName">Enter First Name</label>
    </div>
    <div class="form-floating w-50">
    <input type="text" class="form-control" id="floatingLName" placeholder="Enter Last Name" name="lname" value="<?= $row["last_name"] ?>" required>
    <label for="floatingLName">Enter Last Name</label>
    </div>
    </div>
    <div class="d-flex gap-2 mb-3">
    <div class="form-floating w-50">
    <input type="email" class="form-control" id="floatingEmail" placeholder="Enter Email Name" name="email" value="<?= $row["email"] ?>" disabled>
    <label for="floatingEmail">Email</label>
    </div>
    <div class="form-floating w-50">
    <input type="number" class="form-control" id="floatingPhone" placeholder="Enter Phone Number" name="phone" value="<?= $row["phone"] ?>" required>
    <label for="floatingPhone">Enter Phone Number</label>
    </div>
    </div>
    <div class="d-flex gap-2 mb-3">
    <div class="form-floating w-50">
    <input type="text" class="form-control" id="floatingAddress" placeholder="Enter Address" name="address" value="<?= $row["address"] ?>">
    <label for="floatingAddress">Enter Address</label>
    </div>
    <div class="form-floating w-50">
    <input type="text" class="form-control" id="floatingState" placeholder="Enter State" name="state" value="<?= $row["state"] ?>" required>
    <label for="floatingState">Enter State</label>
    </div>
    </div>
    <div class="d-flex gap-2 mb-3">
    <div class="form-floating w-50">
    <input type="number" class="form-control" id="floatingPCode" placeholder="Enter Pincode" name="pincode" value="<?= $row["pincode"] ?>" required>
    <label for="floatingPCode">Pincode</label>
    </div>
    <input type="hidden" name="id" value="<?= $row["user_id"] ?>">
    <div class="form-floating w-50">
    <input type="date" class="form-control" id="floatingDate" placeholder="Enter Date of Birth" name="dob" value="<?= $row["dob"] ?>" required>
    <label for="floatingDate">Enter DOB</label>
    </div>
    </div>
    <div class="text-center">
    <button type="submit" name="profileBtn" class="btn btn-primary w-25 mb-3">Update Profile</button>
    </div>
    </form>
    </div>
   </div>
   </div>
</div>

<?php include("includes/footer.php");
}else{
    $_SESSION['message'] = "Login to Continue..";
    $_SESSION['message_type'] = "success";
    header("Location: /login.php");
}
?>