
<!-- scroll to top button -->
<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa-solid fa-plane-up"></i></button>

<!-- footer section start here  -->
<div class="footer container-fluid">
  <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 mt-4 border-top">
    <div class="col-md-4 d-flex align-items-center">
      <p class="mb-3 mb-md-0 text-body-secondary">&copy; <span id="footerYear"></span> <span class="theme-color fw-bold"><?= ucfirst($webSplitName[0]) ?></span><?= str_replace($webSplitName[0], "", $websiteName) ?>. Made with ❤️ in India.</p>
    </div>

    <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
      <li class="ms-3"><a class="text-body-secondary" href="#">Terms & Conditions</a></li>
      <li class="ms-3"><a class="text-body-secondary" href="#">Privacy Policy</a></li>
    </ul>
  </footer>
</div>
<!-- footer section end here -->

</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js" integrity="sha512-uKQ39gEGiyUJl4AI6L+ekBdGKpGw4xJ55+xyJG7YFlJokPNYegn9KwQ3P8A7aFQAUtUsAQHep+d/lrGqrbPIDQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>