<?php
// for logout or destory session
session_start();
unset($_SESSION['userLogged']);
unset($_SESSION['fname']);
$_SESSION['message_type'] = "success";
$_SESSION['message'] = "Logout Successfully.";
header("Location: /");

?>