<?php
    //file used to connect to the database
     require "admin/database/dbconn.php";
    //file used for showing website name and other basic details
    require "admin/database/function.php";
    ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ucfirst(settings("website_title")); ?> | <?= ucfirst(settings("website_name")) ?></title>
    <!-- Favicon link -->
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">
    <!-- bootstrap link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- font awesome link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- datatable css cdn link  -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" />
    <!-- custom css -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body onload="loadFun()">
    <!-- preloader -->
    <div id="preloader">
    <div class="spinner-grow text-primary mb-3" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
    <div class="website-name-heading">
    <h4><?= settings("website_name"); ?></h3>
    </div>
    </div>
    <main id="main-section">
    <!-- header section start here -->
    <?php
        //getting website name
        $websiteName = settings("website_name");
        $webSplitName = str_split($websiteName, 4);
        //session start from here
        session_start(); 
        //using this for getting current page
        $page = basename($_SERVER["PHP_SELF"]);
        //using this for getting today's date
        date_default_timezone_set("Asia/Kolkata");
        $currentTime = date("h:ia");
        $currentDate = date("Y-m-d");

        //header code start
        $fixed = "";
        $textColor = "";
        if($page == "index.php"){
            $fixed = "fixed-top";
            $textColor = "";
        }else{
            $fixed = "sticky-top bg-white shadow";
            $textColor = "text-dark";
        }
    ?>
    <nav class="navbar navbar-expand-lg <?= $fixed; ?>" id="navbar">
    <div class="container-fluid">
        <a class="navbar-brand <?= $textColor; ?>" href="/" id="navbar-brand"><span class="theme-color"><?= ucfirst($webSplitName[0]) ?></span><?= str_replace($webSplitName[0], "", $websiteName) ?></a>
        <button class="btn border" id="nav-menu"><i class="fa-solid fa-bars fa-lg"></i></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <div id="navBar-close" class="mb-3"><i class="fa-solid fa-xmark fa-lg"></i></div>
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
            <a class="nav-link <?= $textColor; ?> <?= $page == 'index.php' ? "Active" : "" ?>" href="/">Home</a>
            </li>
            <li class="nav-item">
            <a class="nav-link <?= $textColor; ?> <?= $page == 'about.php' ? "Active" : "" ?>" href="about.php">About</a>
            </li>
            <li class="nav-item">
            <a class="nav-link <?= $textColor; ?> <?= $page == 'contact.php' ? "Active" : "" ?>" href="contact.php">Contact</a>
            </li>
        </ul>
        <div class="navBar-right d-flex gap-1">
            <?php
            if(isset($_SESSION['userLogged']) && $_SESSION['userLogged'] == true){
            ?>
            <div class="d-flex align-items-center dropdown me-1">
                <a class="fw-bold theme-color dropdown-toggle text-uppercase" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="fa-solid fa-circle-user fa-lg me-2"></i><?= $_SESSION['fname']; ?>
                </a>
                <ul class="dropdown-menu user-drop">
                    <li><a class="dropdown-item" href="tickets.php">view Ticket</a></li>
                    <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                </ul>
            </div>
            <a href="includes/logout.php" class="btn btn-danger" onclick="confirm('Are you sure you want to logout?')"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
            <?php    
            }else{
            ?>
            <a href="login.php" class="btn btn-primary">Login</a>
            <a href="register.php" class="btn btn-outline-primary">Register</a>
            <?php
            }
            ?>
        </div>
        </div>
    </div>
    </nav>
    <!-- header section end here  -->