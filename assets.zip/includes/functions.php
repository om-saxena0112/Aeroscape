<?php
//for calculating the base price from all over price
function taxBase($price){
    $base = ($price * 18) / 100;
    $base = $price - $base;
    return $base;
}
//for calculating the tax price from all over price
function taxFee($price){
    $fee = ($price * 18) / 100;
    return $fee;
}
//for converting date integer month into month name
function ModifyDate($date){
    $monthName = ['January', 'Febuary', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $monthInt = (int)substr($date, 5, 6);
    $month = $monthName[$monthInt - 1];
    $date = strtotime($date);
    $date = date('d m,Y', $date);
    $date = str_replace("$monthInt", $month, $date);
    return $date;
}
//age calculator take user DOB and return age 
function ageCal($dob){
    $str = "$dob";
    $str = explode("-",$str);
    $year = date("Y");
    $month = date("m");

    if($str[1] <= $month){
    $age = $year - (int)$str[0];
    }else{
    $age = ($year - (int)$str[0]) - 1 ;
    }

    return $age;
}

?>