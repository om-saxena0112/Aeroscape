<?php include("includes/header.php");
if(isset($_SESSION['userLogged'])){
    header("Location: /flight/");
}else{
?>

<div class="pageNameBox container-fluid py-4  mb-2">
    <div class="pageName">
        <h2 class="text-center">Register</h2>
    </div>
</div>

<?php
if (isset($_SESSION['message'])) {
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
  <?= $_SESSION['message']; ?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php 
unset($_SESSION['message']);   
}
?>

<div class="register-form mb-4">
    <div class="register-container w-75 mx-auto">
        <div class="card shadow w-50 mx-auto py-4">
            <div class="register-heading">
                <h3 class="text-center">Welcome to <span class="theme-color">Aero</span>scape</h3>
            </div>
            <div class="card-body">
            <form action="admin/includes/code.php" method="POST">
            <div class="d-flex gap-4">
            <div class="form-floating w-100 mb-3">
                <input type="text" class="form-control" id="floatingFName" name="fname" placeholder="Enter First Name" required>
                <label for="floatingFName">First Name</label>
            </div>
            <div class="form-floating w-100 mb-3">
                <input type="text" class="form-control" id="floatingLName" name="lname" placeholder="Enter Last Name" required>
                <label for="floatingLName">Last Name</label>
            </div>
            </div>
            <div class="form-floating mb-3">
                <input type="email" class="form-control" id="floatingEmail" name="email" placeholder="Enter Email" required>
                <label for="floatingEmail">Email</label>
            </div>
            <div class="d-flex gap-4">
            <div class="form-floating w-100 mb-3">
                <input type="date" class="form-control" id="floatingAge" name="dob" placeholder="Enter Your Age" required>
                <label for="floatingAge">Date Of Birth</label>
            </div>
            <div class="form-floating w-100 mb-3">
                <input type="number" class="form-control" id="floatingPhone" name="phone" placeholder="Enter Phone Number" required>
                <label for="floatingLName">Phone Number</label>
            </div>
            </div>
            <div class="form-floating mb-3">
                <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Enter Password" required>
                <label for="floatingPassword">Password</label>
            </div>
            <div class="form-floating mb-3">
                <input type="password" class="form-control" id="floatingCPassword" name="cPassword" placeholder="Enter Confirm Password" required>
                <label for="floatingCPassword">Confirm Password</label>
            </div>
            <div class="text-center mb-3">
            <button class="btn btn-primary w-50 mx-auto mb-3" name="registerBtn">Register</button>
            </div>
            </form>
            <div class="signup-link mb-3">
                <p class="text-center mb-0">Already Have an Account! <a href="login.php" class="theme-color fw-bold">Login Here.</a></p>
            </div>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php");
}
?>