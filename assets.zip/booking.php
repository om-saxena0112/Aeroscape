<?php include("includes/header.php");
include "includes/functions.php";
if(isset($_SESSION['userLogged']) && $_SESSION['userLogged'] == true){
    $id = base64_decode(urldecode($_GET['flight_id']));
    $class = base64_decode(urldecode($_GET['class']));
    $doj = base64_decode(urldecode($_GET['id']));
    if($id != " " && $doj == $doj){
        //flight data
        $result = mysqli_query($conn, "SELECT * FROM `flights` WHERE flight_id='$id'");
        $row = mysqli_fetch_assoc($result);
        $airId= $row["airline_id"];
        $airArrival = $row["arrival_city"];
        $airDeparture = $row["departure_city"];
        //airline data
        $airResult = mysqli_query($conn, "SELECT * FROM `airlines` WHERE airline_id='$airId'");
        $airRow = mysqli_fetch_assoc($airResult);
        //fetching seat from schedule table
        $seatResult = mysqli_query($conn, "SELECT economy_seat, bussiness_seat FROM `flights_schedule` WHERE flight_id='$id' AND schedule_date='$doj'");
        $scheduleRow = mysqli_fetch_assoc($seatResult);
        $economySeat = $scheduleRow["economy_seat"];
        $businessSeat = $scheduleRow["bussiness_seat"];
        //airport name for arrival city
        $arrivalResult = mysqli_query($conn, "SELECT city_airport_name FROM `citys` WHERE city_name='$airArrival'");
        $arrivalRow = mysqli_fetch_assoc($arrivalResult);
        //airport name for departure city
        $departureResult = mysqli_query($conn, "SELECT city_airport_name FROM `citys` WHERE city_name='$airDeparture'");
        $departureRow = mysqli_fetch_assoc($departureResult);
        //fetching user details
        $userId = $_SESSION['userId'];
        $userResult = mysqli_query($conn, "SELECT * FROM `users` WHERE user_id='$userId'");
        $userRow = mysqli_fetch_assoc($userResult);

if (isset($_SESSION['message'])) {
?>
<div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
    <?= $_SESSION['message']; ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php 
    unset($_SESSION['message']);   
}
?>

<div class="flight-search-box container-fluid py-4"></div>

<div class="bookingContainer container mb-4">
    <h3 class="mb-3 text-white">Complete Your Booking</h3>
    <div class="booking-box">
    <form action="admin/includes/code.php" method="POST">
    <div class="booking my-2">
        <div class="booking-info mb-3">
        <div class="card py-3">
            <div class="card-body">
                <div class="airline-info card shadow py-2">
                    <div class="airline-details mb-3">
                        <div class="locations px-3 mb-2">
                            <h5 class="mb-0"><?= $row["arrival_city"] == "delhi" ? "New Delhi" : ucfirst($row["arrival_city"]);  ?></h5>
                            <i class="fa-solid fa-arrow-right"></i>
                            <h5 class="mb-0"><?= ucfirst($row["departure_city"]); ?></h5>
                        </div>
                        <div class="other-info px-3">
                            <input type="hidden" name="flight_id" value="<?= $id; ?>">
                            <input type="hidden" name="doj" value="<?= $doj; ?>">
                            <div class="travel-date fw-bold bg-warning px-1 py-1"><?= ModifyDate($doj); ?></div>
                            <div class="flight-duration"><?= $row["flight_stop"]; ?> . <?= $row["duration"]; ?></div>
                        </div>
                    </div>

                    <div class="flight-detail-info px-2 mb-3">
                        <div class="flight-name-icon">
                            <div class="flight-icon">
                                <img src="<?= $airRow["airline_image"]; ?>" class="img-fluid" alt="">
                            </div>
                            <div class="flight-name"><?= ucfirst($airRow["airline_name"]); ?></div>
                            <div class="vr"></div>
                            <div class="flight-number"><?= $row["flight_number"]; ?></div>
                        </div>
                        <div class="class-type">
                            <p class="mb-0"><?= ucfirst($class); ?></p>
                            <input type="hidden" name="class" value="<?= $class; ?>">
                        </div>
                    </div>

                    <div class="flight-info-container">
                        <div class="flight-duration-info">
                            <div class="arrival">
                                <div class="arrival-time"><p class="mb-0 fw-bold"><?= substr($row["arrival_time"], 0, 5); ?></p></div>
                                <div class="airport-info"><i class="fa-regular fa-circle me-1"></i><span class="fw-bold"><?= $row["arrival_city"] == "delhi" ? "New Delhi" : ucfirst($row["arrival_city"]);  ?></span>. <?= $arrivalRow["city_airport_name"]; ?>. Terminal 3</div>
                            </div>
                            <div class="airline-type">
                                <div class="vr me-2"></div>
                                <p class="mb-0"><?= $row["flight_stop"]; ?></p>
                            </div>
                            <div class="destination">
                                <div class="destination-time"><p class="mb-0 fw-bold"><?= substr($row["departure_time"], 0 ,5); ?></p></div>
                                <div class="airport-info"><i class="fa-regular fa-circle me-1"></i><span class="fw-bold"><?= ucfirst($row["departure_city"]); ?></span>. <?= $departureRow["city_airport_name"]; ?>. Terminal 1</div>
                            </div>
                        </div>
                        <div class="checkin-info">
                            <div class="baggage">
                                <p>Baggage</p>
                                <small class="fw-bold">ADULT</small>
                            </div>
                            <div class="check-in">
                                <p>Check-in</p>
                                <small class="fw-bold">15Kg(1 piece only)</small>
                            </div>
                            <div class="cabin">
                                <p>Cabin</p>
                                <small class="fw-bold">7kg(1 piece only)</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="tarveller-details mb-3">
            <div class="card py-3">
                <div class="card-body">
                    <div class="traveller-heading mb-3">
                        <h5>Traveller Details</h5>
                    </div>

                    <div class="add-traveller mb-3">
                        <input type="hidden" name="user_id" value="<?= $userRow["user_id"]; ?>">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingName" name="user_name" value="<?= $userRow["first_name"]." ".$userRow["last_name"]; ?>" placeholder="Enter Name">
                            <label for="floatingName">Name</label>
                        </div>
                        <div class="form-floating">
                            <input type="number" class="form-control" id="floatingAge" name="user_age" value="<?= $userRow["age"] ?>" placeholder="Enter Age">
                            <label for="floatingAge">Age</label>
                        </div>
                        <div class="form-floating">
                            <select class="form-select" id="floatingGender" name="user_gender">
                            <option <?= $userRow["gender"] == "" ? "selected" : "" ?>>Select your Gender</option>
                            <option value="male" <?= $userRow["gender"] == "male" ? "selected" : "" ?>>Male</option>
                            <option value="female" <?= $userRow["gender"] == "female" ? "selected" : "" ?>>Female</option>
                            </select>
                            <label for="floatingGender">Gender</label>
                        </div>
                        <!-- <div class="addTraveller w-50">
                            <button class="btn btn-primary w-100">Add <i class="fa-solid fa-plus"></i></button>
                        </div> -->
                    </div>

                    <div class="booking-address mb-3">
                        <div class="booking-heading mb-3">
                            <h6 class="mb-0">Booking details will be sent to</h6>
                        </div>

                        <div class="add-booking-address">
                        <div class="form-floating">
                            <input type="tel" class="form-control" id="floatingPhone" name="user_phone" value="<?= $userRow["phone"]; ?>" placeholder="Enter Phone Number">
                            <label for="floatingPhone">Phone Number</label>
                        </div>
                        <div class="form-floating">
                            <input type="email" class="form-control" id="floatingEmail" name="user_email" value="<?= $userRow["email"]; ?>" placeholder="Enter Email">
                            <label for="floatingEmail">Email</label>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="traveller-address mb-3">
            <div class="card py-3">
                <div class="card-body">
                <div class="traveller-address-heading mb-3">
                <h5 class="mb-0">Your Pincode & State</h5><span> (Require for generating for invoice.)</span>
                </div>

                <div class="add-traveller-address mb-3">
                    <div class="form-floating">
                            <input type="number" class="form-control" id="floatingPin" name="user_pin" value="<?= $userRow["pincode"]; ?>" placeholder="Enter Pin Code" required>
                            <label for="floatingPin">Pin Code</label>
                    </div>
                    <div class="form-floating">
                            <input type="text" class="form-control" id="floatingState" name="user_state" value="<?= $userRow["state"]; ?>" placeholder="Enter State" required>
                            <label for="floatingState">State</label>
                    </div>
                    <div class="form-floating">
                            <textarea class="form-control" id="floatingAddress" name="user_address" placeholder="Enter Address"><?= $userRow["address"]; ?></textarea>
                            <label for="floatingAddress">Address(Optional)</label>
                    </div>
                </div>
                </div>
            </div>
        </div>
        <?php
            //economy price is going to increase if seat is less than 10
            if($economySeat < 10){
                $ePrice = $row["economy_price"] + 1000;
            }else{
                $ePrice = $row["economy_price"];
            }
            //business price is going to increase if seat is less than 10
            if($businessSeat < 10){
                $bPrice = $row["bussiness_price"] + 1500;
            }else{
                $bPrice = $row["bussiness_price"];
            }
        ?>
        <input type="hidden" name="ticket_price" value="<?= $class == "economy" ? $ePrice : $bPrice; ?>">
        <div class="nextBtn">
            <button type="submit" name="bookingBtn" class="btn btn-primary">Continue</button>
        </div>
    </div>
    <!-- </form> -->
    <div class="fare-breakup my-2">
        <div class="card mb-4 py-3">
            <div class="card-body">
            <div class="fare-summary">
                <div class="fare-summary-heading">
                    <h5 class="mb-3">Fare Summary</h5>
                </div>

                <div class="fare-summary-list">
                    <div class="base-fare mb-3">
                        <div class="base-heading">
                            <h6 class="mb-3">Base Fare</h6>
                        </div>
                        <div class="base-fare-price">
                            <p class="mb-3">₹<?= $class == "economy" ? number_format(taxBase($ePrice)) : number_format(taxBase($bPrice)) ?></p>
                        </div>
                    </div>
                    <div class="tax my-3">
                        <div class="tax-heading">
                            <h6 class="mb-3">Tax & Surcharges</h6>
                        </div>
                        <div class="tax-price">
                            <p class="mb-3">₹<?= $class == "economy" ? number_format(taxFee($ePrice)) : number_format(taxFee($bPrice)) ?></p>
                        </div>
                    </div>
                    <div class="total-amount pt-3">
                        <div class="total-heading">
                            <h6 class="mb-2">Total Amount</h6>
                        </div>
                        <div class="total-price">
                            <h6 class="mb-2">₹<?= $class == "economy" ? number_format($ePrice) : number_format($bPrice) ?></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

    <div class="card py-3">
        <div class="card-body">
        <div class="payment-method">
            <div class="payment-heading">
                <h5 class="mb-3">Payment Method</h5>
            </div>
            <div class="payment-option">
                <div class="form-floating">
                    <select class="form-select" id="floatingPayment" name="payment_method" required>
                    <option selected>Select Payment Method</option>
                    <option value="cash">Cash</option>
                    <option value="upi">UPI</option>
                    </select>
                    <label for="floatingPayment">Payment</label>
                </div>
            </div>
        </div>
        </div>
    </div>
    </form>
    </div>
</div>
</div>


<?php include("includes/footer.php");
    }else{
        $_SESSION['message'] = "Something Went Wrong!";
        $_SESSION['message_type'] = "danger";
        header("Location: /");
    }
}else{
    $_SESSION['message'] = "Login to Continue..";
    $_SESSION['message_type'] = "success";
    header("Location: /login.php");
}
?>