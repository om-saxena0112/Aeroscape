<?php include("includes/header.php");
include "includes/functions.php";
if(isset($_SESSION['userLogged']) && $_SESSION['userLogged'] == true){

//for showing message    
if (isset($_SESSION['message'])) {
?>
    <div class="alert alert-<?= $_SESSION['message_type']; ?> alert-dismissible fade show" role="alert">
      <?= $_SESSION['message']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php 
unset($_SESSION['message']);   
}      
// checking whether to show ticket or not
if(isset($_GET["id"]) || isset($_GET["ticket_id"])){
    //come to this after ticket is booked    
// if(isset($_GET["id"]) && isset($_GET["doj"]) && isset($_GET["status"]) && isset($_GET["class"])){
if(isset($_GET["id"])){

    $ticket_id = base64_decode(urldecode($_GET["id"]));
    // $doj = base64_decode(urldecode($_GET["doj"]));
    // $class = base64_decode(urldecode($_GET["class"]));
    // $status = $_GET["status"];

    $ticketResult = mysqli_query($conn, "SELECT * FROM `tickets` WHERE ticket_id='$ticket_id'");
    $ticketRow = mysqli_fetch_assoc($ticketResult);
    $flightId = $ticketRow["flight_id"];
    //fetching flight data with the help of flight id
    $Result = mysqli_query($conn, "SELECT * FROM `flights` WHERE flight_id='$flightId'");
    $flightRow = mysqli_fetch_assoc($Result);
    $airId = $flightRow["airline_id"];
    //fetching airline name form airline table
    $airResult = mysqli_query($conn, "SELECT airline_name FROM `airlines` WHERE airline_id='$airId'");
    $airRow = mysqli_fetch_assoc($airResult);
}
if(isset($_GET["ticket_id"])){
    //come to this if you are viewing the ticket
    $ticket_id = base64_decode(urldecode($_GET["ticket_id"]));
    $ticketResult = mysqli_query($conn, "SELECT * FROM `tickets` WHERE ticket_id='$ticket_id'");
    $ticketRow = mysqli_fetch_assoc($ticketResult);
    $flightId = $ticketRow["flight_id"];
    $scheduleId = $ticketRow["schedule_id"];
    //fetching flight data with the help of flight id
    $flightResult = mysqli_query($conn, "SELECT * FROM `flights` WHERE flight_id='$flightId'");
    $flightRow = mysqli_fetch_assoc($flightResult);
    $airId = $flightRow["airline_id"];
    //fetching airline name form airline table
    $airResult = mysqli_query($conn, "SELECT airline_name FROM `airlines` WHERE airline_id='$airId'");
    $airRow = mysqli_fetch_assoc($airResult);
}
?>
  
<div class="flight-search-box container-fluid py-4"></div>

<div class="e-ticket container mb-4">
    <div class="ticket card w-75 py-2 my-2">
        <div class="card-body">
            <div class="left-ticket">
                <div class="ticket-heading d-flex justify-content-between align-items-center border-bottom mb-3">
                    <h4 class="heading fw-bold"><span class="theme-color">Aero</span>scape</h4>
                    <h6><?= ucfirst($ticketRow["class"]); ?></h6>
                </div>
                <div class="airline-info d-flex justify-content-between align-items-center mb-3">
                    <div class="airline">
                        <div class="heading text-uppercase fw-bold">airline</div>
                        <p class="mb-0 text-capitalize"><?= $airRow["airline_name"] ?></p>
                    </div>
                    <div class="arrival-city">
                        <div class="heading text-uppercase fw-bold">from</div>
                        <p class="mb-0 text-capitalize"><?= $flightRow["arrival_city"] == "delhi" ? "New Delhi" : $flightRow["arrival_city"] ?>, IN</p>
                    </div>
                    <div class="departure-city">
                        <div class="heading text-uppercase fw-bold">to</div>
                        <p class="mb-0 text-capitalize"><?= $flightRow["departure_city"] == "delhi" ? "New Delhi" : $flightRow["departure_city"] ?>, IN</p>
                    </div>
                </div>
                <div class="passenger-info d-flex justify-content-between align-items-center mb-3">
                    <div class="passenger">
                        <div class="heading text-uppercase fw-bold">passenger</div>
                        <p class="mb-0 text-capitalize"><?= $ticketRow["user_name"]; ?></p>
                    </div>
                    <div class="boarding-time">
                        <div class="heading text-uppercase fw-bold">boarding</div>
                        <?php $boardingTime = strtotime($flightRow["arrival_time"]); $boardingTime = $boardingTime - 3600; ?>
                        <p class="mb-0"><?= date('g:i A', $boardingTime); ?></p>
                    </div>
                </div>
                <div class="other-info d-flex justify-content-between mb-3">
                    <div class="arrival-time">
                        <div class="heading text-uppercase fw-bold">arrival</div>
                        <p class="mb-2"><?= ModifyDate($ticketRow["date_of_travel"]) ?></p>
                        <p class="mb-0"><?= date('g:i A', strtotime($flightRow["arrival_time"])); ?></p>
                    </div>
                    <div class="departure-time">
                        <div class="heading text-uppercase fw-bold">Destination</div>
                        <p class="mb-2"><?= ModifyDate($ticketRow["date_of_travel"]) ?></p>
                        <p class="mb-0"><?= date('g:i A', strtotime($flightRow["departure_time"])); ?></p>
                    </div>
                    <div class="gate">
                        <div class="heading text-uppercase fw-bold">gate no.</div>
                        <p class="mb-0">A22</p>
                    </div>
                    <div class="seat">
                        <div class="heading text-uppercase fw-bold">seat no.</div>
                        <p class="mb-0"><?= $ticketRow["seat_number"] ?></p>
                    </div>
                </div>
                </div>
                <div class="right-ticket">
                    <div class="heading-center">
                        <h3 class="mb-0">Aeroscape</h3>
                    </div>
                </div>
        </div>
    </div>
    <div class="w-25 py-2">
        <div class="card py-2 mb-3">
            <div class="card-body">
                <div class="booking-status w-100 text-center">
                    <button class="btn btn-outline-<?= $ticketRow["status"] == 1 ? "success" : "warning" ?> text-uppercase fw-bold mb-3"><?= $ticketRow["status"] == 1 ? "Booked SuccessFully" : "Booking Pending" ?></button>
                    <?php
                        //checking whether the date or time is correct according to the current date and time in order to book the ticket
                         $DOJ = date($ticketRow["date_of_travel"]);
                         $arrivalTime = strtotime($flightRow["arrival_time"]);
                         $arrivalTime = date("H:i:s", $arrivalTime);
                         $currentTime = date("H:i:s");
                        //  echo $DOJ , $currentDate;
                        //  echo $arrivalTime, ",", $currentTime;
                         $flightStatus = "Departured";
                         $flightStatus_type = "primary";
                         if($DOJ >= $currentDate){
                            if($DOJ == $currentDate){
                                // echo $DOJ;
                                if($arrivalTime > $currentTime){
                                    // echo $DOJ;
                                    $flightStatus_type = "info";
                                    $flightStatus = "Not Yet Departured";
                                }
                            }}
                    ?>
                    <button class="btn btn-outline-<?= $flightStatus_type; ?> text-uppercase fw-bold"><?= $flightStatus; ?></button>
                </div>
            </div>
        </div>
        <div class="card py-4">
            <div class="card-body">
                <div class="fare-summary w-100">
                <div class="fare-summary-heading">
                    <h5 class="mb-3">Fare Summary</h5>
                </div>

                <div class="fare-summary-list">
                    <div class="base-fare mb-3">
                        <div class="base-heading">
                            <h6 class="mb-3">Base Fare</h6>
                        </div>
                        <div class="base-fare-price">
                            <p class="mb-3">₹<?= number_format(taxBase($ticketRow["ticket_price"])) ?></p>
                        </div>
                    </div>
                    <div class="tax my-3">
                        <div class="tax-heading">
                            <h6 class="mb-3">Tax & Surcharges</h6>
                        </div>
                        <div class="tax-price">
                            <p class="mb-3">₹<?= number_format(taxFee($ticketRow["ticket_price"])) ?></p>
                        </div>
                    </div>
                    <div class="total-amount pt-3">
                        <div class="total-heading">
                            <h6 class="mb-2">Total Amount</h6>
                        </div>
                        <div class="total-price">
                            <h6 class="mb-2">₹<?= number_format($ticketRow["ticket_price"]) ?></h6>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php");
    }
}else{
    $_SESSION['message'] = "Login to Continue..";
    $_SESSION['message_type'] = "success";
    header("Location: /flight/login.php");
}
?>